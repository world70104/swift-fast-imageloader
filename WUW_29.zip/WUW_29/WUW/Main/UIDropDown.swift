//
//  UIDropDown.swift
//  UIDropDown
//
//  Created by Isaac Gongora on 13/11/15.
//  Copyright © 2015 Isaac Gongora. All rights reserved.
//

import UIKit

public class UIDropDown: UIControl {
    
    fileprivate var table: UITableView!
    fileprivate var arrow: UIImageView!
    public var touchStatus = 0
    public fileprivate(set) var selectedIndex: Int?
    public var options = [String]()
    
    // Border
    public var cornerRadius: CGFloat = 3.0 {
        didSet{
            self.layer.cornerRadius = cornerRadius
        }
    }
    public var borderWidth: CGFloat = 0.5 {
        didSet{
            self.layer.borderWidth = borderWidth
        }
    }
    public var borderColor: UIColor = .black {
        didSet{
            self.layer.borderColor = borderColor.cgColor
        }
    }
    
    // Table Configurations
    
    public var tableHeight: CGFloat = 160.0
    public var rowHeight: CGFloat?
    public var rowBackgroundColor: UIColor?
    
    // Closures
    fileprivate var privatedidSelect: (String, Int) -> () = {option, index in }
    fileprivate var privateTableWillAppear: () -> () = { }
    fileprivate var privateTableDidAppear: () -> () = { }
    fileprivate var privateTableWillDisappear: () -> () = { }
    fileprivate var privateTableDidDisappear: () -> () = { }
    
    //    var m_mMenuVC: MenuViewController
    
    // Init
    public override init(frame: CGRect ) {
        super.init(frame: frame)
        setup()
    }
    
    public required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        setup()
    }
    
    // Class methods
    public func resign() -> Bool {
        if isSelected {
            hideTable()
        }
        return true
    }
    
    fileprivate func setup() {
        arrow = UIImageView(frame: CGRect(x: 0, y: 0, width: self.frame.height, height: self.frame.height))
        arrow.image = UIImage(named: "icon_threedot")
        self.arrow.alpha = 1
        self.addSubview(arrow)
        self.addTarget(self, action: #selector(touch), for: .touchUpInside)
    }

    @objc fileprivate func touch() {
        isSelected = !isSelected
        isSelected ? showTable() : hideTable()
    }

    fileprivate func showTable() {
        touchStatus = 1
        privateTableWillAppear()
        table = UITableView(frame: CGRect(x: self.frame.minX,
                                          y: self.frame.minY,
                                          width: self.frame.width,
                                          height: self.frame.height))
        //table.separatorStyle = .none
        table.dataSource = self
        table.delegate = self
        table.alpha = 0
        table.layer.cornerRadius = cornerRadius
        table.layer.borderWidth = borderWidth
        table.layer.borderColor = UIColor.clear.cgColor
        table.rowHeight = self.frame.height
        self.superview?.insertSubview(table, belowSubview: self)
        
        UIView.animate(withDuration: 0.3,
                       delay: 0.0,
                       usingSpringWithDamping: 1,
                       initialSpringVelocity: 0.5,
                       options: .curveEaseInOut, animations: {
                            self.table.frame = CGRect(x: UIScreen.main.bounds.width - 210, y: self.frame.origin.y, width: 200, height: self.frame.height * 3)
                            self.table.alpha = 1
                            self.arrow.image = UIImage(named: "icon_threedot")
        }, completion: { (finished) in
            self.privateTableDidAppear()
        })
    }
    
    public func hideTable() {
        touchStatus = 0
        privateTableWillDisappear()
        UIView.animate(withDuration: 0.3,
                       delay: 0,
                       usingSpringWithDamping: 0.9,
                       initialSpringVelocity: 0.1,
                       options: .curveEaseInOut,
                       animations: { () -> Void in
                            self.table.frame = CGRect(x: self.frame.minX, y: self.frame.minY, width: self.frame.width, height: 0)
                            self.table.alpha = 0
                            self.arrow.image = UIImage(named: "icon_threedot")},
                       completion: { (didFinish) -> Void in
                            self.table.removeFromSuperview()
                            self.isSelected = false
                            self.privateTableDidDisappear()
        })
    }
    
    // Actions Methods
    public func didSelect(completion: @escaping (_ option: String, _ index: Int) -> ()) {
        privatedidSelect = completion
    }
    
    public func tableWillAppear(completion: @escaping () -> ()) {
        privateTableWillAppear = completion
    }
    
    public func tableDidAppear(completion: @escaping () -> ()) {
        privateTableDidAppear = completion
    }
    
    public func tableWillDisappear(completion: @escaping () -> ()) {
        privateTableWillDisappear = completion
    }
    
    public func tableDidDisappear(completion: @escaping () -> ()) {
        privateTableDidDisappear = completion
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue : UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

extension UIDropDown: UITableViewDataSource, UITableViewDelegate {
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return options.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "UIDropDownCell"
        
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: cellIdentifier)
        }
        
        if rowBackgroundColor != nil {
            cell!.contentView.backgroundColor = rowBackgroundColor
        }
        cell!.textLabel!.text = options[indexPath.row]
        cell!.textLabel!.textColor = UIColor.black
        cell!.textLabel!.textAlignment = .left
        cell!.textLabel!.font = UIFont.systemFont(ofSize: 17)
        cell!.accessoryType = .none
        cell!.selectionStyle = .none
        return cell!
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedIndex = (indexPath as NSIndexPath).row
        
        UIView.animate(withDuration: 0.6,
                       animations: { () -> Void in
        })
        
        tableView.reloadData()
        
        hideTable()
        
        privatedidSelect("\(self.options[indexPath.row])", selectedIndex!)
    }
}
