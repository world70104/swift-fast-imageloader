//
//  StoreViewController.swift
//  Sample
//
//  Created by POLARIS on 11/28/17.
//  Copyright © 2017 POLARIS. All rights reserved.
//

import UIKit
import PagingMenuController

private struct PagingMenuOptions: PagingMenuControllerCustomizable {
    public var ContactVC : ContactVC!
    public var WishListVC : WishListVC!
    
    fileprivate var componentType: ComponentType {
        return .all(menuOptions: MenuOptions(), pagingControllers: pagingControllers)
    }
    
    fileprivate var pagingControllers: [UIViewController] {
        
        return [ContactVC, WishListVC]
    }
    
    fileprivate struct MenuOptions: MenuViewCustomizable {
        var displayMode: MenuDisplayMode {
            return .segmentedControl
        }
        var itemsOptions: [MenuItemViewCustomizable] {
            return [MenuItem1(), MenuItem2()]
        }
    }
    
    fileprivate struct MenuItem1: MenuItemViewCustomizable {
        var displayMode: MenuItemDisplayMode {
            return .text(title: MenuItemText(text: NSLocalizedString("CONTACT", comment: "")))
        }
    }
    
    fileprivate struct MenuItem2: MenuItemViewCustomizable {
        var displayMode: MenuItemDisplayMode {
            return .text(title: MenuItemText(text: NSLocalizedString("MY WISHLIST", comment: "")))
        }
    }
}

class MainViewController: UIViewController, UIGestureRecognizerDelegate, UISearchBarDelegate {
    var contactTitleBar: UIView!
    var contactTitleLabel: UILabel!
    var contactSearchButton : UIButton!
    var contactTreedotButton : UIButton!
    var contactSetting: UIDropDown!
    
    var wishTitleBar: UIView!
    var wishTitleLabel: UILabel!
    var wishSearchButton : UIButton!
    var wishGiftButton : UIButton!
    var wishTreedotButton : UIButton!
    var wishDeleteButton : UIButton!
    var wishCancelButton : UIButton!
    var wishSetting: UIDropDown!
    
    var ContactVC:ContactVC!
    var WishListVC:WishListVC!

    var searchBarForContact: UISearchBar!
    var searchBarForWish: UISearchBar!
    
    // Initiate tap geture recognizer object
    let tapGesture : UITapGestureRecognizer = UITapGestureRecognizer()
    
    var pageState = true
    
    var appDelegate:AppDelegate!
    var mwait:Wait!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        ContactVC = self.storyboard?.instantiateViewController(withIdentifier: "ContactVC") as! ContactVC
        WishListVC = self.storyboard?.instantiateViewController(withIdentifier: "WishListVC") as! WishListVC
        
        ContactVC.mvc = self
        WishListVC.mvc = self
        
        var options = PagingMenuOptions()
        options.ContactVC = ContactVC
        options.WishListVC = WishListVC
        let pagingMenuController = PagingMenuController(options: options)
        pagingMenuController.view.frame.origin.y += 64
        pagingMenuController.view.frame.size.height -= 64

        pagingMenuController.onMove = { state in
            switch state {
            case let .willMoveController(menuController, previousMenuController):
                if self.pageState == true {
                    self.contactTitleBar.isHidden = true
                    self.contactSetting.isHidden = true
                    self.wishTitleBar.isHidden = false
                    self.wishSetting.isHidden = false
                    self.pageState = false
                } else {
                    self.contactTitleBar.isHidden = false
                    self.contactSetting.isHidden = false
                    self.wishTitleBar.isHidden = true
                    self.wishSetting.isHidden = true
                    self.pageState = true
                }
  
                print(previousMenuController)
                print(menuController)
                // WishList View ?
                if menuController.view.frame.origin.x != 0 {
                    // icon init
                    self.drawIconInWish( kind : 0 )
                    // Update the wishlist data
                    WishListCommon.Shared.sendWLDataGetRequest(wlvc: self.WishListVC, kind: 0)
                    // table view edting disable
                    self.WishListVC.tableView.setEditing(false, animated: true)
                }
            case let .didMoveController(menuController, previousMenuController):
                
                print(previousMenuController)
                print(menuController)
            case let .willMoveItem(menuItemView, previousMenuItemView):
                
                print(previousMenuItemView)
                print(menuItemView)
            case let .didMoveItem(menuItemView, previousMenuItemView):
               
                print(previousMenuItemView)
                print(menuItemView)
           case .didScrollStart:
                print("Scroll start")
            case .didScrollEnd:
                print("Scroll end")
            }
        }

        addChildViewController(pagingMenuController)
        view.addSubview(pagingMenuController.view)
        
        pagingMenuController.didMove(toParentViewController: self)
        setupContactBar()
        setupWishBar()
        setupSearchBarForContact()
        setupSearchBarForWish()

        // set tap gesture recognizer delegte
//        self.tapGesture.delegate = self
        
        // set tap gesture target
//        self.tapGesture.addTarget(self, action: #selector(MainViewController.increaseCount))
        
        // add tap gesture recognizer into view
//        contactTitleBar.addGestureRecognizer(self.tapGesture)

//        wishTitleBar.addGestureRecognizer(self.tapGesture)
    }
    
    // function - increase count when screen tapped.
/*    @objc func increaseCount(){
        print("tap")
        if contactSetting.touchStatus == 1 {
            contactSetting.hideTable()
        }
        if wishSetting.touchStatus == 1 {
            wishSetting.hideTable()
        }
    }*/
    
    func setupContactBar() {
        contactTitleBar = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 64))
        contactTitleBar.backgroundColor = hexStringToUIColor(hex: "065E52")
        view.addSubview(contactTitleBar)
        
        contactTitleLabel = UILabel(frame: CGRect(x: 16, y: 20, width: 100, height: 44))
        contactTitleLabel.text = "WUW"
        contactTitleLabel.font = UIFont.boldSystemFont(ofSize: 24)
        contactTitleLabel.textColor = UIColor.white
        contactTitleBar.addSubview(contactTitleLabel)
        
        contactSearchButton = UIButton(frame: CGRect(x: UIScreen.main.bounds.width - contactTitleLabel.frame.height * 2, y: contactTitleLabel.frame.origin.y, width: contactTitleLabel.frame.height, height: contactTitleLabel.frame.height))
        contactSearchButton.setImage(UIImage(named: "icon_search"), for: UIControlState.normal)
        contactSearchButton.addTarget(self, action: #selector(startSearch(_:)), for: .touchUpInside)
        contactTitleBar.addSubview(contactSearchButton)
        
        contactTreedotButton = UIButton(frame: CGRect(x: UIScreen.main.bounds.width - contactTitleLabel.frame.height, y: contactTitleLabel.frame.origin.y, width: contactTitleLabel.frame.height, height: contactTitleLabel.frame.height))
        contactTreedotButton.setImage(UIImage(named: "icon_threedot"), for: UIControlState.normal)
        contactTreedotButton.addTarget(self, action: #selector(dropMenuContact(_:)), for: .touchUpInside)
        contactTitleBar.addSubview(contactTreedotButton)

        self.contactSetting = UIDropDown(frame: CGRect(x: UIScreen.main.bounds.width - contactTitleLabel.frame.height, y: contactTitleLabel.frame.origin.y, width: contactTitleLabel.frame.height, height: contactTitleLabel.frame.height))
        self.contactSetting.options = [
            NSLocalizedString("Update List", comment: ""),
            NSLocalizedString("Profile", comment: "")
        ]
        self.contactSetting.didSelect { (option, index) in
            
            /////////////////   Update contact data   //////////////////////////////
            if index == 0 {
                self.appDelegate.objViewController = nil
                self.appDelegate.objMainViewController = self
                // Update List
                self.appDelegate.isContactUpdate = true

                // ready the wait
                self.mwait = Wait(mParentView:self.view,
                        msg: NSLocalizedString("Updating contact…", comment: ""),
                        bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                        fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
                self.mwait.startWait()

                // load the contact for uodate
                self.appDelegate.getRegisterPhoneNumberFromServer()                
            }
                
            ////////////////////////////   Profile    ///////////////////////////
            else if index == 1 {
                guard let uvc =
                    self.storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as? ProfileViewController else {
                    return
                }
                self.present(uvc, animated: false)
            }
            print("You just select: \(option) at index: \(index)")
        }
 //       view.addSubview(contactSetting)

    }
    
    func setupWishBar() {
        wishTitleBar = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 64))
        wishTitleBar.backgroundColor = hexStringToUIColor(hex: "065E52")
        view.addSubview(wishTitleBar)
        
        wishTitleLabel = UILabel(frame: CGRect(x: 16, y: 20, width: 100, height: 44))
        wishTitleLabel.text = "WUW"
        wishTitleLabel.font = UIFont.boldSystemFont(ofSize: 24)
        wishTitleLabel.textColor = UIColor.white
        wishTitleBar.addSubview(wishTitleLabel)
        
        wishSearchButton = UIButton(frame: CGRect(x: UIScreen.main.bounds.width - wishTitleLabel.frame.height * 3, y: wishTitleLabel.frame.origin.y, width: wishTitleLabel.frame.height, height: wishTitleLabel.frame.height))
        wishSearchButton.setImage(UIImage(named: "icon_search"), for: UIControlState.normal)
        wishSearchButton.addTarget(self, action: #selector(startSearch(_:)), for: .touchUpInside)
        wishTitleBar.addSubview(wishSearchButton)
        
        wishGiftButton = UIButton(frame: CGRect(x: UIScreen.main.bounds.width - wishTitleLabel.frame.height * 2, y: wishTitleLabel.frame.origin.y, width: wishTitleLabel.frame.height, height: wishTitleLabel.frame.height))
        wishGiftButton.setImage(UIImage(named: "icon_gift"), for: UIControlState.normal)
        wishGiftButton.addTarget(self, action: #selector(goAddItem(_:)), for: .touchUpInside)
        wishTitleBar.addSubview(wishGiftButton)
        
        wishTreedotButton = UIButton(frame: CGRect(x: UIScreen.main.bounds.width - wishTitleLabel.frame.height, y: wishTitleLabel.frame.origin.y, width: wishTitleLabel.frame.height, height: wishTitleLabel.frame.height))
        wishTreedotButton.setImage(UIImage(named: "icon_threedot"), for: UIControlState.normal)
        wishTreedotButton.addTarget(self, action: #selector(dropMenuWish(_:)), for: .touchUpInside)
        wishTitleBar.addSubview(wishTreedotButton)
        
        wishDeleteButton = UIButton(frame: CGRect(x: UIScreen.main.bounds.width - wishTitleLabel.frame.height * 2, y: wishTitleLabel.frame.origin.y, width: wishTitleLabel.frame.height, height: wishTitleLabel.frame.height))
        wishDeleteButton.setImage(UIImage(named: "icon_delete"), for: UIControlState.normal)
        wishDeleteButton.addTarget(self, action: #selector(doDelete(_:)), for: .touchUpInside)
        wishTitleBar.addSubview(wishDeleteButton)
        wishDeleteButton.isHidden = true
        
        wishCancelButton = UIButton(frame: CGRect(x: UIScreen.main.bounds.width - wishTitleLabel.frame.height, y: wishTitleLabel.frame.origin.y, width: wishTitleLabel.frame.height, height: wishTitleLabel.frame.height))
        wishCancelButton.setImage(UIImage(named: "icon_close"), for: UIControlState.normal)
        wishCancelButton.addTarget(self, action: #selector(doCancel(_:)), for: .touchUpInside)
        wishTitleBar.addSubview(wishCancelButton)
        wishCancelButton.isHidden = true

        self.wishSetting = UIDropDown(frame: CGRect(x: UIScreen.main.bounds.width - wishTitleLabel.frame.height, y: wishTitleLabel.frame.origin.y, width: wishTitleLabel.frame.height, height: wishTitleLabel.frame.height))
        self.wishSetting.options = [
            NSLocalizedString("Update Wishlist", comment: ""),
            NSLocalizedString("Add new item", comment: ""),
            NSLocalizedString("Manage wishlist", comment: "")
        ]
        self.wishSetting.didSelect { (option, index) in
            if index == 0 {
                // Update the wishlist data
                WishListCommon.Shared.sendWLDataGetRequest(wlvc: self.WishListVC, kind: 0)
            } else if index == 1 {
                guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "AddItemVC") as? AddItemViewController else {
                    return
                }
                self.present(uvc, animated: false)
            } else if index == 2 {
                guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "ManageWishListVC") as? ManageWishListViewController else {
                    return
                }
                self.present(uvc, animated: false)
            }
            print("You just select: \(option) at index: \(index)")
        }
//        view.addSubview(wishSetting)
        
        wishTitleBar.isHidden = true
        wishSetting.isHidden = true
    }
    
    func setupSearchBarForContact() {
        searchBarForContact = UISearchBar(frame: CGRect(x: 0, y: contactTitleLabel.frame.origin.y, width: UIScreen.main.bounds.width - contactSetting.frame.width, height: contactTitleLabel.frame.height))
        searchBarForContact.backgroundColor = hexStringToUIColor(hex: "065E52")
        searchBarForContact.barTintColor = hexStringToUIColor(hex: "065E52")
        searchBarForContact.searchBarStyle = .minimal
        searchBarForContact.showsCancelButton = true
        searchBarForContact.tintColor = UIColor.white
        searchBarForContact.textColor = UIColor.white
        contactTitleBar.addSubview(searchBarForContact)
        searchBarForContact.isHidden = true
        searchBarForContact.delegate = self
    }
    
    func setupSearchBarForWish() {
        searchBarForWish = UISearchBar(frame: CGRect(x: 0, y: wishTitleLabel.frame.origin.y, width: UIScreen.main.bounds.width - wishSetting.frame.width * 2, height: wishTitleLabel.frame.height))
        searchBarForWish.backgroundColor = hexStringToUIColor(hex: "065E52")
        searchBarForWish.barTintColor = hexStringToUIColor(hex: "065E52")
        searchBarForWish.searchBarStyle = .minimal
        searchBarForWish.showsCancelButton = true
        searchBarForWish.tintColor = UIColor.white
        searchBarForWish.textColor = UIColor.white
        wishTitleBar.addSubview(searchBarForWish)
        searchBarForWish.isHidden = true
        searchBarForWish.delegate = self
    }

    @objc func dropMenuContact(_ sender: UIButton) {
        let alert = UIAlertController(title: nil,
            message: nil,
            preferredStyle: .actionSheet)
        
        /////////////////   Update contact data   //////////////////////////////
        alert.addAction(UIAlertAction(
            title: NSLocalizedString(NSLocalizedString("Update List", comment: ""), comment: ""),
            style: .default) { (_) in
                self.appDelegate.objViewController = nil
                self.appDelegate.objMainViewController = self
                // Update List
                self.appDelegate.isContactUpdate = true
                // ready the wait
                self.mwait = Wait(mParentView:self.view,
                                  msg: NSLocalizedString("Updating contact…", comment: ""),
                                  bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                                  fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
                self.mwait.startWait()
                // load the contact for uodate
                self.appDelegate.getRegisterPhoneNumberFromServer()
        })
        ////////////////////////////   Profile    ///////////////////////////
        alert.addAction(UIAlertAction(
            title: NSLocalizedString("Profile", comment: ""),
            style: .default) { (_) in
            guard let uvc =
                self.storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as? ProfileViewController else {
                    return
            }
            self.present(uvc, animated: false)
        })
        ////////////////////////////   Cancel    ///////////////////////////
        alert.addAction(UIAlertAction(
            title: NSLocalizedString("Cancel", comment: ""),
            style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }

    @objc func dropMenuWish(_ sender: UIButton) {
        let alert = UIAlertController(title: nil,
                message: nil,  preferredStyle: .actionSheet)
        /////////////////   Update Wishlist   //////////////////////////////
        alert.addAction(UIAlertAction(
            title: NSLocalizedString(NSLocalizedString("Update Wishlist", comment: ""), comment: ""),
            style: .default) { (_) in
                WishListCommon.Shared.sendWLDataGetRequest(wlvc: self.WishListVC, kind: 0)
        })
        /////////////////   Add new item   //////////////////////////////
        alert.addAction(UIAlertAction(
        title: NSLocalizedString(NSLocalizedString("Add new item", comment: ""), comment: ""),
        style: .default) { (_) in
            guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "AddItemVC") as? AddItemViewController else {
                return
            }
            self.present(uvc, animated: false)
        })
        /////////////////   Delete item   //////////////////////////////
        alert.addAction(UIAlertAction(
            title: NSLocalizedString(NSLocalizedString("Delete item", comment: ""), comment: ""),
            style: .default) { (_) in
                self.WishListVC.tableView.setEditing(!self.WishListVC.tableView.isEditing, animated: true)
        })
        ////////////////////////////   Manage wishlist    ///////////////////////////
        alert.addAction(UIAlertAction(
            title: NSLocalizedString("Manage wishlist", comment: ""),
            style: .default) { (_) in
                guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "ManageWishListVC") as? ManageWishListViewController else {
                    return
                }
                self.present(uvc, animated: false)
        })
        ////////////////////////////   Cancel    ///////////////////////////
        alert.addAction(UIAlertAction(
            title: NSLocalizedString("Cancel", comment: ""),
            style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }

    @objc func startSearch(_ sender: UIButton) {
        if pageState == true {
            searchBarForContact.isHidden = false
            searchBarForContact.becomeFirstResponder()
        } else {
            searchBarForWish.isHidden = false
            searchBarForWish.becomeFirstResponder()
        }
    }
    
    func searchContactDataAfterInvite() {
        // convert the search text by lowercase
        let _searchText = searchBarForContact.text!.lowercased()
        // filter by string
        if _searchText.count != 0 {
            // filter by index
            ContactCommon.Shared.contactDataIndex = ContactCommon.Shared.contactData.indices.filter{
                ContactCommon.Shared.contactData[$0].name.lowercased().contains(_searchText)
            }
        }
        else {
            ContactCommon.Shared.makeOriginalContactDataIndex()
        }
    }
    
    // show the search result
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // convert the search text by lowercase
        let _searchText = searchText.lowercased()
        // in contact ?
        if searchBar == searchBarForContact {
            // filter by string
            if _searchText.count != 0 {
                // filter by index
                ContactCommon.Shared.contactDataIndex = ContactCommon.Shared.contactData.indices.filter{
                    ContactCommon.Shared.contactData[$0].name.lowercased().contains(_searchText)
                }
            }
            else {
                ContactCommon.Shared.makeOriginalContactDataIndex()
            }
            // Reload the contact  table view
            self.ContactVC.tableView.reloadData()
        }
        // in whishlist ?
        else {
            if _searchText.count != 0 {
                // filter by index
                WishListCommon.Shared.wishListIndex = WishListCommon.Shared.wishListData.indices.filter{
                    WishListCommon.Shared.wishListData[$0].name.lowercased().contains(_searchText)
                }
            }
            else {
                WishListCommon.Shared.makeOriginalWLDataIndex()
            }
            // Reload the wishlist  table view
            self.WishListVC.tableView.reloadData()
        }
    }
    
    // cancel button event
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        // recover the original data
        if searchBar == searchBarForContact {
            ContactCommon.Shared.makeOriginalContactDataIndex()
            // Reload the wishlist  table view
            self.ContactVC.tableView.reloadData()
        } else {
            WishListCommon.Shared.makeOriginalWLDataIndex()
            // Reload the wishlist  table view
            self.WishListVC.tableView.reloadData()
        }
        searchBar.text = ""
        searchBar.isHidden = true
        searchBar.endEditing(true)
    }
    
    @objc func goAddItem(_ sender: UIButton) {
        guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "AddItemVC") as? AddItemViewController else {
            return
        }
        self.present(uvc, animated: false)
    }
    
    @objc func doDelete(_ sender: UIButton) {
        // "question" alert
        let alert = UIAlertController(title: nil,
            message: NSLocalizedString("Are you sure?", comment: ""),
            preferredStyle: .alert)
        let okAction = UIAlertAction(title: NSLocalizedString("Ok", comment: ""),
            style: .default){ (_) in
                print("delete")
                // delete for selected items
                self.WishListVC.deleteItems()
                self.drawIconInWish( kind : 0 )
                self.WishListVC.tableView.setEditing(false, animated: true)
        }
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .default){ (_) in
            return
        }
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: false, completion: nil)
    }
    
    @objc func doCancel(_ sender: UIButton) {
        drawIconInWish( kind : 0 )
        self.WishListVC.tableView.setEditing(false, animated: true)
    }
    
    // kind - 1 : For delete
    //        0 : For no delete
    func drawIconInWish( kind : Int ) {
        if kind == 0 {
            wishSearchButton.isHidden = false
            wishGiftButton.isHidden = false
            wishTreedotButton.isHidden = false
            wishDeleteButton.isHidden = true
            wishCancelButton.isHidden = true
        }
        else {
            wishSearchButton.isHidden = true
            wishGiftButton.isHidden = true
            wishTreedotButton.isHidden = true
            wishDeleteButton.isHidden = false
            wishCancelButton.isHidden = false
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

extension UISearchBar {
    var textColor:UIColor? {
        get {
            if let textField = self.value(forKey: "searchField") as?
                UITextField  {
                return textField.textColor
            } else {
                return nil
            }
        }
        
        set (newValue) {
            if let textField = self.value(forKey: "searchField") as?
                UITextField  {
                textField.textColor = newValue
            }
        }
    }
}
