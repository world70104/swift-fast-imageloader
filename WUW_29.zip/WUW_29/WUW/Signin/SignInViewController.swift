//
//  ViewController.swift
//  WUW
//
//  Created by POLARIS on 04/20/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

class SignInViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var countryCode: UITextField!
    @IBOutlet var phoneNumber: UITextField!
    @IBOutlet var birthday: UITextField!
    @IBOutlet var signButton: UIButton!

    var _date : Date?
    
    // wait dlg for contact request
    var mwait:Wait!
    override func viewDidLoad() {
        super.viewDidLoad()
        // get the UUID
        Common.Shared.myProfileData.mUUID = (UIDevice.current.identifierForVendor?.uuidString)!
        //get country code
        Common.Shared.mCurrentCountryName = (Locale.current as NSLocale).object(forKey: .countryCode) as? String
        if Common.Shared.mCurrentCountryName != nil {
            Common.Shared.mCurrentCountryCode =
                getCountryCodeOrName(_countryName: (Common.Shared.mCurrentCountryName)!, _countryCode:"")!
            if Common.Shared.mCurrentCountryCode.count != 0 {
                print(countryCode!)
                countryCode.text! = "+" + Common.Shared.mCurrentCountryCode
                Common.Shared.mCurrentCountryCode =  countryCode.text!
            }
        }
        let paddingView: UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 10, height: 20))
        phoneNumber.leftView = paddingView
        phoneNumber.leftViewMode = .always
        countryCode.delegate = self
        phoneNumber.delegate = self
        birthday.delegate = self
    }

    // MARK: TextField Delegate
    @objc func datePickerChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
//        formatter.dateStyle = .short
        formatter.dateFormat = "dd/MM/yyyy"
        birthday.text = formatter.string(from: sender.date)
        _date = sender.date
        print("Try this at home")
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        let datePicker = UIDatePicker()
        if textField == birthday {
            birthday.inputView = datePicker
        }
        datePicker.datePickerMode = .date
        if _date != nil  {
            datePicker.date = _date!
        }
        let formatter = DateFormatter()
//        formatter.dateStyle = .short
        formatter.dateFormat = "dd/MM/yyyy"
        // check the country name?
        birthday.text = formatter.string(from: datePicker.date)
        datePicker.addTarget(self, action: #selector(datePickerChanged(sender:)), for: .valueChanged)
        
        print("This Worked")
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        // country code ?
        if textField == countryCode {
            // country code check
            if let text = textField.text {
                let isCountry = getCountryCodeOrName(_countryName: "", _countryCode:text)
                // country code error?
                if isCountry?.count == 0 {
                    print("country code error ")
                    // "error" alert
                    let alert = UIAlertController(title: nil,
                        message: NSLocalizedString("Input the country code", comment: ""),
                        preferredStyle: .alert)
                    let cancelAction = UIAlertAction(
                        title: NSLocalizedString("Ok", comment: ""),
                        style: .cancel){ (_) in
                        textField.becomeFirstResponder()
                        return
                    }
                    alert.addAction(cancelAction)
                    self.present(alert, animated: false, completion: nil)
                }
            }
        } else if textField == phoneNumber {  // phone number ?
            // phone number check
            if let text = textField.text {
                let number = CharacterSet.decimalDigits.isSuperset(of: CharacterSet(charactersIn: text))
                if number == false {
                    print("phone number error")
                    // "error" alert
                    let alert = UIAlertController(title: nil,
                        message: NSLocalizedString("Phone number input error", comment: ""),
                        preferredStyle: .alert)
                    let cancelAction = UIAlertAction(
                        title: NSLocalizedString("Ok", comment: ""),
                        style: .cancel){ (_) in
                        textField.becomeFirstResponder()
                        return
                    }
                    alert.addAction(cancelAction)
                    self.present(alert, animated: false, completion: nil)
                } else if text.count == 0 {
                    print("Input phone number.")
                    // "error" alert
                    let alert = UIAlertController(title: nil,
                            message: NSLocalizedString("Input phone number", comment: ""),
                            preferredStyle: .alert)
                    let cancelAction = UIAlertAction(
                        title: NSLocalizedString("Ok", comment: ""),
                        style: .cancel){ (_) in
                        textField.becomeFirstResponder()
                        return
                    }
                    alert.addAction(cancelAction)
                    self.present(alert, animated: false, completion: nil)
                }
            }
        }
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var returnValue = true
        // country code ?
        if textField == countryCode {
            if let text = textField.text {
                let count = text.count
                // min 1 digit(+)
                if count <= 1 {
                    if string.count == 0 {
                        returnValue = false
                    }
                } else if count > 3 { // max 3 digit
                    if string.count != 0 {
                        returnValue = false
                    }
                }
            }
        } else if textField == phoneNumber { // phone number ?
            if let text = textField.text {
                let count = text.count
                // max 15 digit
                if count > 15 {
                    if string.count != 0 {
                        returnValue = false
                    }
                }
            }
        }
        return returnValue
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        birthday.resignFirstResponder()
        return true
    }
    
    // MARK: Helper Methods
    func closekeyboard() {
        self.view.endEditing(true)
    }
    
    // MARK: Touch Events
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        closekeyboard()
    }
    
    @IBAction func goSignIn(_ sender: Any) {
        if self.countryCode.text?.count == 0 {
            Common.Shared.alertMessage(viewController:self,
                tableviewController:nil,
                message: NSLocalizedString("Input the country code.", comment: ""))
        } else if self.phoneNumber.text?.count == 0 {
            Common.Shared.alertMessage(viewController:self,
                tableviewController:nil,
                message: NSLocalizedString("Input phone number", comment: ""))
        } else if self.birthday.text?.count == 0 {
            Common.Shared.alertMessage(viewController:self,
                tableviewController:nil,
                message: NSLocalizedString("Input birthday.", comment: ""))
        } else {
            Common.Shared.myProfileData.mPhoneNumber = self.countryCode.text! + self.phoneNumber.text!
            Common.Shared.myProfileData.mCountryCode = self.countryCode.text!
            Common.Shared.myProfileData.mBirthday = self.birthday.text!
            // if current code get fail?
            if Common.Shared.mCurrentCountryCode.count == 0  {
                Common.Shared.mCurrentCountryCode = Common.Shared.myProfileData.mCountryCode
            }
            sendRequest()
        }
    }
    
    func getCountryCodeOrName(_countryName:String, _countryCode:String)->String?{
        
        // get the country code
        if _countryCode == "" {
            let countryCode = Common.Shared.countryNameCodes[_countryName]
            Common.Shared.myProfileData.mCountryName = _countryName
            return countryCode
        }
        
        // get the country name
        var countryName = ""
        var countryCode = _countryCode
        countryCode.remove(at: countryCode.startIndex)
        for countryNameCode in Common.Shared.countryNameCodes {
            if countryNameCode.value == countryCode {
                countryName = countryNameCode.key
                break
            }
        }
        return countryName
    }
    
    func sendRequest() {
        let url = URL(string: Common.SERVER_URL + "users.php?options=sign_in")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // body
        var postString = Common.PARAM_DEVICE_ID + "=" + Common.Shared.myProfileData.mUUID + "&"
        // phonenumber '+' to '%2B'
        let possibleNumberStr = Common.Shared.myProfileData.mPhoneNumber.replacingOccurrences(of: "+", with: "%2B")
        postString = postString + Common.PARAM_PHONE_NUMBER + "=" + possibleNumberStr + "&"

        postString = postString + Common.PARAM_BIRTHDAY + "=" + Common.Shared.myProfileData.mBirthday + "&"
        
        // phonenumber '+' to '%2B'
        let possibleCountryCodeStr = Common.Shared.myProfileData.mCountryCode.replacingOccurrences(of: "+", with: "%2B")
        postString = postString + Common.PARAM_COUNTRY_CODE + "=" + possibleCountryCodeStr
        
        request.httpBody = postString.data(using: .utf8)
        // signButton no enable
        signButton.isEnabled = false
        // ready the wait
        mwait = Wait(mParentView:self.view,
                     msg: NSLocalizedString("Signing in…", comment: ""),
                     bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                     fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
        mwait.startWait()
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 0
                if data != nil {
                    do {
                        // signin fail
                        check = 1
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    print("success")
                                    check = 0
                                    // get the user id
                                    let userinfo = json["userinfo"] as? [String:Any]
                                    Common.Shared.myProfileData.mUserID = (userinfo!["id"] as? String)!
                                    Common.Shared.myProfileData.mPhoto_url = (userinfo!["photo_url"] as? String)!
                                    // get ther block phone number
                                    Common.Shared.myProfileData.mBlockPhoneNumbers.removeAll()
                                    let _blockPhoneNumbers = (userinfo!["block_phoneNumbers"] as? String)!
                                    let data = Data(_blockPhoneNumbers.utf8)
                                    do {
                                        let blockPhoneNumbers = try JSONSerialization.jsonObject(with: data) as! [String]
                                        for blockPhoneNumber in blockPhoneNumbers {
                                            Common.Shared.myProfileData.mBlockPhoneNumbers.append(blockPhoneNumber)
                                        }
                                    } catch {
                                        print(error)
                                    }

                                    // get the wishlist
                                    WishListCommon.Shared.wishListData.removeAll()
                                    let wishlists = json["wishlist"] as? [Any]
                                    for wishlist in wishlists! {
                                        let wishlistData = wishlist as? [String : Any]
                                        let ratingStr = wishlistData!["rating"] as! String
                                        let oneWishlist = WishListItemData(
                                            id : wishlistData!["id"] as? String,
                                            name : wishlistData!["name"] as? String,
                                            price : wishlistData!["price"] as? String,
                                            rating : Double(ratingStr),
                                            description : wishlistData!["description"] as? String,
                                            photo_url : wishlistData!["photo_url"] as? String,
                                            status : wishlistData!["status"] as? String,
                                            orderer_id : wishlistData!["orderer_id"] as? String,
                                            created_at : wishlistData!["created_at"] as? String,
                                            owner_id : wishlistData!["owner_id"] as? String
                                        )
                                        
                                        WishListCommon.Shared.wishListData.append(oneWishlist)
                                    }
                                    WishListCommon.Shared.saveWishListData(viewController:self, tableviewController:nil)
                                } else {  // fail?
                                    print("failure")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                // Stop the wait
                self.mwait.stopWait()
                // signButton no enable
                self.signButton.isEnabled = true
                if check == 0 {
                    // Save the parameter
                    Common.Shared.saveMyProfileDataFile(viewController: self, tableviewController: nil)
                    // go to MainVC
                    guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "MainVC") as? MainViewController else {
                        return
                    }
                    self.present(uvc, animated: false)
                }
                else if check == 1 {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                            message: NSLocalizedString("Failed.", comment: ""))
                } else {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                            message: NSLocalizedString("Server is busy now.", comment: ""))
                }
            }
        }
        task.resume()
    }
}
