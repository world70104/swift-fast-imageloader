//
//  ViewController.swift
//  PageControl
//
//  Created by Gabriel Theodoropoulos on 15/6/15.
//  Copyright (c) 2015 Gabriel Theodoropoulos. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var goButton: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!
    
    // Initialize it right away here
    private let contentImages = ["nature_pic_1",
                                 "nature_pic_2",
                                 "nature_pic_3",
                                 "nature_pic_4"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        goButton.isHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        configureScrollView()
        configurePageControl()

        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        // load the contact for uodate
        appDelegate.objViewController = self
        appDelegate.objMainViewController = nil
        appDelegate.getRegisterPhoneNumberFromServer()
    }
    
    @IBAction func onGo(_ sender: Any) {
         // check the parameter
         let pList = UserDefaults.standard
         // check the parameter
         let checkID = pList.string(forKey:Common.KEY_PROFILE_FILE_SAVE)
         // if present?
         if checkID != nil {
         // Load the parameter
         Common.Shared.readMyProfileDataFile(viewController: nil, tableviewController: nil)
         // go to MainVC
            guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "MainVC") as? MainViewController else {
                return
            }
            self.present(uvc, animated: false)
         }
         else {
         // go to Signin
            guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "SignInVC") as? SignInViewController else {
                return
            }
            self.present(uvc, animated: false)
         }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // MARK: Custom method implementation
    func configureScrollView() {
        // Enable paging.
        scrollView.isPagingEnabled = true
        
        // Set the following flag values.
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.scrollsToTop = false
        
        // Set the scrollview content size.
        scrollView.contentSize = CGSize(width:scrollView.frame.size.width * CGFloat(contentImages.count), height:scrollView.frame.size.height)
        
        // Set self as the delegate of the scrollview.
        scrollView.delegate = self
        
        // Load the TestView view from the TestView.xib file and configure it properly.
        var i = 0
        repeat {
            // Load the TestView view.
            let testView = Bundle.main.loadNibNamed("TestView", owner: self, options: nil)![0] as! UIView
            
            // Set its frame and the background color.
            testView.frame = CGRect(
                x:CGFloat(i) * scrollView.frame.size.width,
                y:scrollView.frame.origin.y,
                width:scrollView.frame.size.width,
                height: scrollView.frame.size.height)

            let bgImage = UIImage(named: contentImages[i])!;
            let imageView   = UIImageView(frame: self.view.bounds)
            imageView.image = bgImage
            testView.addSubview(imageView)
            
            // Add the test view as a subview to the scrollview.
            scrollView.addSubview(testView)
            i += 1
        } while(i<contentImages.count)
    }
    
    func configurePageControl() {
        // Set the total pages to the page control.
        pageControl.numberOfPages = contentImages.count
        // Set the initial page.
        pageControl.currentPage = 0
    }
    
    // MARK: UIScrollViewDelegate method implementation
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // Calculate the new page index depending on the content offset.
        let currentPage = floor(scrollView.contentOffset.x / UIScreen.main.bounds.size.width);
        
        // Set the new page index to the page control.
        if pageControl.currentPage != Int(currentPage) {
            pageControl.currentPage = Int(currentPage)
            
            if pageControl.currentPage >= (contentImages.count - 1) {
                goButton.isHidden = false
            }
            else {
                goButton.isHidden = true
            }
        }
    }
    
    // MARK: IBAction method implementation
    @IBAction func changePage(sender: AnyObject) {
        // Calculate the frame that should scroll to based on the page control current page.
        var newFrame = scrollView.frame
        newFrame.origin.x = newFrame.size.width * CGFloat(pageControl.currentPage)
        scrollView.scrollRectToVisible(newFrame, animated: true)
    }
}
