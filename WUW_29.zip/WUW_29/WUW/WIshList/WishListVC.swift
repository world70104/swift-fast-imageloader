//
//  SecondVC.swift
//  Sample
//
//  Created by POLARIS on 01/17/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

class WishListVC: UITableViewController {

    // mvc controller
    var mvc : MainViewController!

    // wait dlg for image upload request
    var mwait:Wait!
    
    // indexpath for delete
    var deleteIndexPaths = [IndexPath]()
    // wihlist index for delete
    var deleteWishlistIndexs = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        WishListCommon.Shared.sendWLDataGetRequest(tableviewController:self)
        self.tableView.allowsMultipleSelectionDuringEditing = true

    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return WishListCommon.Shared.wishListIndex.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let index = WishListCommon.Shared.wishListIndex[indexPath.row]
        let mWishListItemData = WishListCommon.Shared.wishListData[index]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "WishListCell") as! WishListCell

        // read the  image file
        cell.photo.kf.indicatorType = .activity
        cell.photo.kf.setImage(
            with: URL(string: Common.SERVER_URL + WishListCommon.Shared.wishListData[index].photo_url ),
            placeholder: nil)
        // item status
        if mWishListItemData.status == "1" {
            cell.state.image = UIImage(named: "item_lock")
        } else if mWishListItemData.status == "0" {
            cell.state.image = UIImage(named: "item_unlock")
        } else if mWishListItemData.status == "2" {
            cell.state.image = UIImage(named: "item_gift")
        }
        
        cell.nameLabel.text = mWishListItemData.name
        cell.priceLable.text = mWishListItemData.price
        cell.star.rating = mWishListItemData.rating
        cell.star.isUserInteractionEnabled = false
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        tableView.setEditing(true, animated: true)
        if tableView.isEditing != true {
            let selectedIndex = WishListCommon.Shared.wishListIndex[indexPath.row]
            guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "EditItemVC") as? EditItemViewController else {
                return
            }
            uvc.index = selectedIndex
            self.present(uvc, animated: false)
        } else {
            //////////////////////////
            print("select for delete")
            mvc.wishSearchButton.isHidden = true
            mvc.wishGiftButton.isHidden = true
            mvc.wishTreedotButton.isHidden = true
            mvc.wishDeleteButton.isHidden = false
            mvc.wishCancelButton.isHidden = false
        }
    }
    
    func deleteItems() {
        deleteIndexPaths.removeAll()
        deleteWishlistIndexs.removeAll()
        // get selected row
        if let indexPaths = self.tableView.indexPathsForSelectedRows {
            deleteIndexPaths = indexPaths
            for indexPath in indexPaths {
                deleteWishlistIndexs.append( WishListCommon.Shared.wishListIndex[indexPath.row] )
            }
            if indexPaths.count != 0 {
                // delete process
                deleteWishList()
            }
        }
    }
    
    // delete the WishList
    func deleteWishList() {
        let url = URL(string: Common.SERVER_URL + "users.php?options=delete_wishlists")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        //--------------- body -----------------------------
        var postString = "wishlist_ids=["
        // id add for delete
        for deleteWishlistIndex in self.deleteWishlistIndexs {
            postString +=
                WishListCommon.Shared.wishListData[deleteWishlistIndex].id + ","
        }
        postString.remove(at: postString.index(before: postString.endIndex))
        postString += "]"
        // convert the utf8 data
        request.httpBody = postString.data(using: .utf8)
        // ready the wait
        mwait = Wait(mParentView:self.view,
            msg:NSLocalizedString("Deleting wish item…", comment: ""),
            bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
            fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
        mwait.startWait()
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 1
                if data != nil {
                    do {
                        // signin fail
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    check = 0
                                    print("success")
                                } else {  // fail?
                                    print("failure")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                // Stop the wait
                self.mwait.stopWait()
                if check == 0 {
                    // get the modified wishlist data
                    WishListCommon.Shared.sendWLDataGetRequest(wlvc: self, kind: 1)
                }
                else if check == 1 {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Failed.", comment: ""))
                } else  {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Server is busy now.", comment: ""))
                }
            }
        }
        task.resume()
    }
}
