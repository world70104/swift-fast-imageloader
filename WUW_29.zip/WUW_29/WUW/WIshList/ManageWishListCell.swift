//
//  ManageWishListCell.swift
//  WUW
//
//  Created by AlexSong on 2018/7/14.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

class ManageWishListCell: UITableViewCell {
    
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var phoneNumber: UILabel!
    @IBOutlet weak var btnBlock: UIButton!
}
