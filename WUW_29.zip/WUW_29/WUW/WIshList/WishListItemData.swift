//
//  WishListItemData.swift
//  WUW
//
//  Created by admin on 2018/4/23.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import Foundation

struct WishListItemData: Codable {
    let id:String
    var name: String
    var price: String
    var rating: Double
    var description: String
    var photo_url: String
    let status: String
    let orderer_id: String
    let created_at: String
    let owner_id: String
    // init
    init(
        id: String? = nil,
        name: String? = nil,
        price: String? = nil,
        rating: Double? = nil,
        description: String? = nil,
        photo_url: String? = nil,
        status: String? = nil,
        orderer_id: String? = nil,
        created_at: String? = nil,
        owner_id: String? = nil
    ) {
        self.id = id!
        self.name = name!
        self.price = price!
        self.rating = rating!
        self.description = description!
        self.photo_url = photo_url!
        self.status = status!
        self.orderer_id = orderer_id!
        self.created_at = created_at!
        self.owner_id = owner_id!
    }
}
