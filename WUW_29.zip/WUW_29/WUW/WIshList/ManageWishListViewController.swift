//
//  ManageWishListViewController.swift
//  WUW
//
//  Created by AlexSong on 2018/7/14.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

class ManageWishListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    @IBOutlet weak var ManageWishListTableView: UITableView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var titleBar: UIView!
    var searchBar: UISearchBar!
    var blockState = 0
    // wait dlg for contact request
    var mwait:Wait!
    
    // contact data index
    var contactDataIndex = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleBar.backgroundColor = hexStringToUIColor(hex: "065E52")
        searchBar = UISearchBar(frame: CGRect(x: 0, y: btnBack.frame.origin.y, width: UIScreen.main.bounds.width - btnBack.frame.width, height: btnBack.frame.height))
        searchBar.backgroundColor = hexStringToUIColor(hex: "065E52")
        searchBar.barTintColor = hexStringToUIColor(hex: "065E52")
        searchBar.searchBarStyle = .minimal
        searchBar.showsCancelButton = true
        searchBar.tintColor = UIColor.white
        searchBar.textColor = UIColor.white
        titleBar.addSubview(searchBar)
        searchBar.isHidden = true
        searchBar.delegate = self
        // for search
        makeOriginalContactDataIndex()
    }
    
    func makeOriginalContactDataIndex() {
        contactDataIndex.removeAll()
        let count = ContactCommon.Shared.contactData.count
        for index in 0..<count {
            contactDataIndex.append(index)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // come in detail view ?
        ManageWishListTableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return contactDataIndex.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // real index
        let mContactData = ContactCommon.Shared.contactData[ contactDataIndex[indexPath.row] ]

        let cell = tableView.dequeueReusableCell(withIdentifier: "ManageWishListCell") as! ManageWishListCell
        
        cell.photo.image = UIImage(named: "empty_profile.png" )
        if mContactData.photoUrl.count != 0 {
            cell.photo.kf.indicatorType = .activity
            cell.photo.kf.setImage(
                with: URL(string: Common.SERVER_URL + mContactData.photoUrl ),
                placeholder: nil)
        }
        
        cell.photo.layer.cornerRadius = (cell.photo.frame.width) / 2
        cell.photo.layer.borderWidth = 0
        cell.photo.layer.masksToBounds = true
        
        cell.name.text = mContactData.name
        
        // phone number
        var phoneNumberStr = ""
        for _phone in mContactData.phone {
            phoneNumberStr = _phone + ","
        }
        if phoneNumberStr != "" {
            phoneNumberStr.remove(at: phoneNumberStr.index(before: phoneNumberStr.endIndex))
        }
        cell.phoneNumber.text = phoneNumberStr

        if mContactData.block == "0" {
            cell.btnBlock.setTitle(
                NSLocalizedString("Block", comment: ""), for: .normal)
            cell.btnBlock.backgroundColor = hexStringToUIColor(hex: "701D1C")
        }
        else {
            cell.btnBlock.setTitle(
                NSLocalizedString("Unlock", comment: ""), for: .normal)
            cell.btnBlock.backgroundColor = self.hexStringToUIColor(hex: "065E52")
        }

        cell.btnBlock.tag = indexPath.row
        cell.btnBlock.addTarget(self, action: #selector(doBlock(_:)), for: .touchUpInside)
        return cell
    }
    
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }

    @objc func doBlock(_ sender: UIButton) {
        let index = sender.tag
        let mContactData = ContactCommon.Shared.contactData[ contactDataIndex[index] ]
        if mContactData.block == "0" {
            ContactCommon.Shared.contactData[contactDataIndex[index]].block = "1"
        }
        else {
            ContactCommon.Shared.contactData[contactDataIndex[index]].block = "0"
        }
        // update direct row only
        let indexPath = IndexPath(item: index, section: 0)
        ManageWishListTableView.reloadRows(at: [indexPath], with: .automatic)
    }
        
    @IBAction func goBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func doSearch(_ sender: Any) {
        searchBar.isHidden = false
        searchBar.becomeFirstResponder()
    }
    
    // show the search result
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // convert the search text by lowercase
        let _searchText = searchText.lowercased()
        // filter by string
        if _searchText.count != 0 {
                // filter by index
                contactDataIndex = ContactCommon.Shared.contactData.indices.filter{
                    ContactCommon.Shared.contactData[$0].name.lowercased().contains(_searchText)
                }
        }
        else {
            makeOriginalContactDataIndex()
        }
        // Reload the contact by search
        ManageWishListTableView.reloadData()
    }
    
    // cancel button event
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        makeOriginalContactDataIndex()
        // Reload the wishlist  table view
        self.ManageWishListTableView.reloadData()

        searchBar.text = ""
        searchBar.isHidden = true
        searchBar.endEditing(true)
    }
    
    // block phone number list
    @IBAction func doCheck(_ sender: Any) {
        // upload the wishlist
        let refreshAlert = UIAlertController(title: "",
            message: NSLocalizedString("Are you sure?", comment: ""),
            preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: NSLocalizedString("Ok", comment: ""),
            style: .default, handler: { (action: UIAlertAction!) in
            // send the block phone number
            self.sendBlockPhoneRequest()
        }))
        refreshAlert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""),
            style: .cancel, handler: { (action: UIAlertAction!) in
        }))
        present(refreshAlert, animated: true, completion: nil)
    }
    
    func sendBlockPhoneRequest() {
        let url = URL(string: Common.SERVER_URL + "users.php?options=block_phone_numbers")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // body
        var postString = Common.PARAM_USER_ID + "=" + Common.Shared.myProfileData.mUserID
        postString += "&" + Common.KEY_BLOCK_PHONE_NUMBERS + "=["
        // get block phone number
        var isBockNumber = false
        for oneContactData in ContactCommon.Shared.contactData {
            // block ?
            if oneContactData.block == "1" {
                for _phone in oneContactData.phone {
                    postString += _phone + ","
                    isBockNumber = true
                }
            }
        }
        // remove the end '
        if isBockNumber {
            postString.remove(at: postString.index(before: postString.endIndex))
        }
        postString += "]"
        // url encoding
        postString = postString.stringUrlEncoding()!
        // convert the utf8 data
        request.httpBody = postString.data(using: .utf8)
        // ready the wait
         mwait = Wait(mParentView:self.view, msg: NSLocalizedString("Loading data…", comment: ""),
         bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
         fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
         mwait.startWait()
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 1
                if data != nil {
                    do {
                        // wishlist update fail
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    check = 0
                                    print("success")
                                    // save file
                                    ContactCommon.Shared.saveContactDataFile( viewController:self,
                                        tableviewController:nil)
                                } else {  // fail?
                                    print("failure")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                // Stop the wait
                self.mwait.stopWait()
                if check == 0 {
                    self.dismiss(animated: true, completion: nil)
                }
                else if check == 1 {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Failed.", comment: ""))
                } else  {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Server is busy now.", comment: ""))
                }
            }
        }
        task.resume()
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
