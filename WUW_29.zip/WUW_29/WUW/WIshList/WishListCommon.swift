//
//  WishListCommon.swift
//  WUW
//
//  Created by admin on 2018/4/23.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import Foundation
import UIKit

final class WishListCommon {
    
    // Can't init is singleton
    private init() { }
    
    // Shared Instance
    static let Shared = WishListCommon()
    
    // wish list
    var wishListData = [WishListItemData]()
    var wishListIndex = [Int]()

    let wishListdataFlie = "_wishlist.json"
    
    // Key for wishlist file save flag
    static let KEY_WISH_LIST_FILE_SAVE = "key_wishlistFileSave"
    static let VALUE_WISH_LIST_FILE_SAVE = "YES"
    
    // wait dlg for contact request
    var mwait:Wait!
    
    // make the original index
    func makeOriginalWLDataIndex() {
        wishListIndex = [Int]()
        let count = wishListData.count
        for index in 0..<count {
            wishListIndex.append(index)
        }
    }

    // Load the wish list data
    // kind 1 - get wish list after delete
    //      0 - normal get wish list
    func sendWLDataGetRequest(wlvc : WishListVC, kind : Int) {
//        let wlvc : WishListVC! = tableviewController as! WishListVC
        let url = URL(string: Common.SERVER_URL + "users.php?options=get_wishlist_data")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // body
        let postString = Common.PARAM_USER_ID + "=" + Common.Shared.myProfileData.mUserID
        request.httpBody = postString.data(using: .utf8)
        if kind == 0 {
            // ready the wait
            mwait = Wait(mParentView:wlvc.view, msg:NSLocalizedString("Refreshing now…", comment: ""),
                bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
            mwait.startWait()
        }
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 0
                if data != nil {
                    do {
                        // signin fail
                        check = 1
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    print("success")
                                    check = 0
                                    // get the wishlist
                                    WishListCommon.Shared.wishListData.removeAll()
                                    let wishlists = json["wishlist"] as? [Any]
                                    for wishlist in wishlists! {
                                        let wishlistData = wishlist as? [String : Any]
                                        let ratingStr = wishlistData!["rating"] as! String
                                        let oneWishlist = WishListItemData(
                                            id : wishlistData!["id"] as? String,
                                            name : wishlistData!["name"] as? String,
                                            price : wishlistData!["price"] as? String,
                                            rating : Double(ratingStr),
                                            description : wishlistData!["description"] as? String,
                                            photo_url : wishlistData!["photo_url"] as? String,
                                            status : wishlistData!["status"] as? String,
                                            orderer_id : wishlistData!["orderer_id"] as? String,
                                            created_at : wishlistData!["created_at"] as? String,
                                            owner_id : wishlistData!["owner_id"] as? String
                                        )
                                        
                                        WishListCommon.Shared.wishListData.append(oneWishlist)
                                    }
                                    let wishListData = WishListCommon.Shared.wishListData
                                    // init the original data
                                    WishListCommon.Shared.wishListIndex = [Int]()
                                    for idx in 0..<wishListData.count {
                                        WishListCommon.Shared.wishListIndex.append(idx)
                                    }
                                } else {  // fail?
                                    print("failure")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                if kind == 0 {
                    // Stop the wait
                    self.mwait.stopWait()
                }
                else {
                    wlvc.mwait.stopWait()
                }
                if check == 0 {
                    wlvc.tableView.reloadData()
                }
                else if check == 1 {
                    Common.Shared.alertMessage(viewController:nil, tableviewController:wlvc,
                            message: NSLocalizedString("Failed.", comment: ""))
                } else {
                    Common.Shared.alertMessage(viewController:nil, tableviewController:wlvc,
                    message: NSLocalizedString("Server is busy now.", comment: ""))
                }
            }
        }
        task.resume()
    }

    // Save the wish list data
    func saveWishListData(viewController:UIViewController?, tableviewController:UITableViewController?) {
        // Item Save
        // wishlistdata to JSON encoder
        let jsonEncoder = JSONEncoder()
        jsonEncoder.outputFormatting = .prettyPrinted
        let jsonData = try? jsonEncoder.encode(wishListData)
        // show the json data
        if let jsonString = String(data: jsonData!, encoding: .utf8) {
            print(jsonString)
        }
        // file write the JSON
        let fileManager = FileManager.default
        var fileURL:URL!
        // get the URL
        let documentDirectory = try? fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor:nil, create:false)
        fileURL = documentDirectory?.appendingPathComponent(wishListdataFlie)
        // write the data file
        do {
            try jsonData!.write(to: fileURL)
            // Set the wishlist file save flag
            let pList = UserDefaults.standard
            pList.set( WishListCommon.VALUE_WISH_LIST_FILE_SAVE,
                       forKey:WishListCommon.KEY_WISH_LIST_FILE_SAVE )
        }
        catch {
            Common.Shared.alertMessage(viewController:viewController,
                tableviewController:tableviewController,
                message: NSLocalizedString("Failed to write file", comment: "") )
            print("Failed to write JSON data: \(error.localizedDescription)")
        }
    }

    // Save the wish list data modify
    func saveModifyWishListData(viewController:UIViewController?, tableviewController:UITableViewController?,
            imageFileNameForDelete:String, wishlistItemIndex:Int) {
        // Item Save
        // wishlistdata to JSON encoder
        let jsonEncoder = JSONEncoder()
        jsonEncoder.outputFormatting = .prettyPrinted
        let jsonData = try? jsonEncoder.encode(wishListData)
        // show the json data
        if let jsonString = String(data: jsonData!, encoding: .utf8) {
            print(jsonString)
        }
        // file write the JSON
        let fileManager = FileManager.default
        var fileURL:URL!
        // get the URL
        let documentDirectory = try? fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor:nil, create:false)
        fileURL = documentDirectory?.appendingPathComponent(wishListdataFlie)

        // delete the image file
        let filename = documentDirectory?.appendingPathComponent(imageFileNameForDelete)
        do {
            try fileManager.removeItem(at: filename!)
        }
        catch {
            print("file delete error")
        }

        // write the data file
        do {
            try jsonData!.write(to: fileURL)
            // Set the wishlist file save flag
            let pList = UserDefaults.standard
            pList.set( WishListCommon.VALUE_WISH_LIST_FILE_SAVE,
                       forKey:WishListCommon.KEY_WISH_LIST_FILE_SAVE )
        }
        catch {
            Common.Shared.alertMessage(viewController:viewController,
                    tableviewController:tableviewController,
                    message: NSLocalizedString("Failed to write file", comment: ""))
            print("Failed to write JSON data: \(error.localizedDescription)")
        }
    }
}
