//
//  EditItemViewController.swift
//  WUW
//
//  Created by master on 7/18/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

class EditItemViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate,
UITextFieldDelegate {
    
    @IBOutlet var profileImage: UIImageView!
    
    var pickedImageData : Data!
    var noImage:Bool!
    
    // index in wishlist
    var index = 0
    
    @IBOutlet var addImageButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    
    @IBOutlet var itemName: UITextField!
    @IBOutlet var itemPrice: UITextField!
    @IBOutlet var itemRating: CosmosView!
    @IBOutlet var itemDescription: UITextView!
    
    var mWishListItemData: WishListItemData!
    // wait dlg for image upload request
    var mwait:Wait!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.profileImage.layer.cornerRadius = (self.profileImage.frame.width) / 2
        self.profileImage.layer.borderWidth = 0
        self.profileImage.layer.masksToBounds = true
        
        self.addImageButton.layer.cornerRadius = self.addImageButton.frame.width / 2
        self.addImageButton.layer.borderWidth = 0
        self.addImageButton.layer.masksToBounds = true
        itemRating.didFinishTouchingCosmos = didFinishTouchingCosmos
//        saveButton.isEnabled = false
        noImage = true
        itemName.delegate = self
        itemPrice.delegate = self
        
        mWishListItemData = WishListCommon.Shared.wishListData[index]
        
        // read the  image file
        self.profileImage.kf.indicatorType = .activity
        self.profileImage.kf.setImage(
            with: URL(string: Common.SERVER_URL + WishListCommon.Shared.wishListData[index].photo_url ),
            placeholder: nil)
        
        // picked image data
        // PNG
//        self.pickedImageData = UIImagePNGRepresentation(profileImage.image!)
//        self.profileImage.image = UIImage(data: self.pickedImageData)

        itemName.text = mWishListItemData.name
        itemPrice.text = mWishListItemData.price
        itemRating.rating = mWishListItemData.rating
        itemDescription.text = mWishListItemData.description
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func goBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveItem(_ sender: Any) {
        // upload the wishlist
        let refreshAlert = UIAlertController(title: "",
            message: NSLocalizedString("Are you sure you want to edit the item?", comment: ""),
            preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: NSLocalizedString("Ok", comment: ""),
            style: .default, handler: { (action: UIAlertAction!) in
            self.mWishListItemData.name = self.itemName.text!
            self.mWishListItemData.price = self.itemPrice.text!
            self.mWishListItemData.rating = self.itemRating.rating
            self.mWishListItemData.description = self.itemDescription.text!
            // delete and add
            self.deleteWishList()
        }))
        refreshAlert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""),
            style: .cancel, handler: { (action: UIAlertAction!) in
        }))
        present(refreshAlert, animated: true, completion: nil)
    }
    
    @IBAction func cancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func imgPicker( _ source : UIImagePickerControllerSourceType) {
        let picker = UIImagePickerController()
        picker.sourceType = source
        picker.delegate = self
        picker.allowsEditing = true
        self.present(picker, animated: true)
    }
    
    @IBAction func addImage(_ sender: Any) {
        let alert = UIAlertController(title: nil,
            message: NSLocalizedString("Image of profile", comment: ""),
            preferredStyle: .actionSheet)
        
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            alert.addAction(UIAlertAction(title: NSLocalizedString("From Gallery", comment: ""),
                style: .default) { (_) in
                self.imgPicker(.photoLibrary)
                self.saveButton.isEnabled = true
            })
        }
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            alert.addAction(UIAlertAction(title: NSLocalizedString("From Camera", comment: ""),
                style: .default) { (_) in
                self.imgPicker(.camera)
                self.saveButton.isEnabled = true
            })
        }
        
        alert.addAction(UIAlertAction(title: NSLocalizedString("Remove image", comment: ""),
            style: .default) { (_) in
            self.profileImage?.image = UIImage(named: "empty_item")
            self.saveButton.isEnabled = false
        })
        
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""),
            style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
            // reSize image with 100 * 100
            var reSizeImage = UIImage()
            reSizeImage = self.resizeImage(image: pickedImage, targetSize: CGSize(width: 100.0, height: 100.0))
            // picked image data
            // PNG
            self.pickedImageData = UIImagePNGRepresentation(reSizeImage)!
            // JPEG
            //    self.pickedImageData = UIImageJPEGRepresentation(reSizeImage, 0.4)!
            
            self.profileImage.image = UIImage(data: self.pickedImageData)
        }
        picker.dismiss(animated: false)
        noImage = false
    }
    
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    func didFinishTouchingCosmos(_ rating: Double) {
        let ratingValue = Float(rating)
        
        if rating == itemRating.rating {
            print(ratingValue)
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if itemName.text == "" || itemPrice.text == "" || self.profileImage?.image == UIImage(named: "empty_item") {
            saveButton.isEnabled = false
        } else {
            saveButton.isEnabled = true
        }
    }
    
    // add the WishList
    func addWishList() {
        let url = URL(string: Common.SERVER_URL + "users.php?options=register_wishlist")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // body
        let pickedImageData = UIImagePNGRepresentation(profileImage.image!)!
        let strData = pickedImageData.base64EncodedString()
        let newStrData = strData.stringUrlEncoding()

        var postString = "user_id=" + Common.Shared.myProfileData.mUserID
        
        let strRating = String(itemRating.rating)
        postString = postString + "&name=" + itemName.text!
        postString = postString + "&price=" + itemPrice.text!
        postString = postString + "&rating=" + strRating
        postString = postString + "&description=" + itemDescription.text!
        
        postString = postString + "&base64=" + newStrData!
        // convert the utf8 data
        request.httpBody = postString.data(using: .utf8)
        // ready the wait
/*
        mwait = Wait(mParentView:self.view, msg: NSLocalizedString("Uploading wish item…", comment: ""),
                     bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                     fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
        mwait.startWait()
*/
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                
                if let httpResponse = response as? HTTPURLResponse {
                    print("error \(httpResponse.statusCode)")
                }
                
                var check = 1
                if data != nil {
                    do {
                        // wishlist update fail
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    check = 0
                                    print("success")
                                    let photoUrl = json["photo_url"] as? String
                                    print(photoUrl!)
                                    // Item Save
                                    self.mWishListItemData.photo_url = photoUrl!
                                    WishListCommon.Shared.wishListData[self.index] = self.mWishListItemData
                                    // sort
                                    let newData = WishListCommon.Shared.wishListData.sorted{ $0.name < $1.name }
                                    WishListCommon.Shared.wishListData = newData
                                    
                                    // file save
                                    WishListCommon.Shared.saveWishListData(viewController:self, tableviewController:nil)
                                } else {  // fail?
                                    print("failure")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                // Stop the wait
                self.mwait.stopWait()
                if check == 0 {
                    self.dismiss(animated: true, completion: nil)
                }
                else if check == 1 {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Failed.", comment: ""))
                } else  {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Server is busy now.", comment: ""))
                }
            }
        }
        task.resume()
    }
    
    // Delete the WishList
    func deleteWishList() {
        let url = URL(string: Common.SERVER_URL + "users.php?options=delete_wishlists")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // body
        let postString = Common.KEY_WISHLIST_IDS + "=[" + self.mWishListItemData.id + "]"
        // convert the utf8 data
        request.httpBody = postString.data(using: .utf8)
        // ready the wait
        mwait = Wait(mParentView:self.view, msg: NSLocalizedString("Updating wishlist…", comment: ""),
                     bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                     fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
        mwait.startWait()
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 1
                if data != nil {
                    do {
                        // wishlist update fail
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    check = 0
                                    print("success")
                                } else {  // fail?
                                    print("failure")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                // Stop the wait
//                self.mwait.stopWait()
                if check == 0 {
                    // add
                    self.addWishList()
                }
                else if check == 1 {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Failed.", comment: ""))
                } else if check >= 2  {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Server is busy now.", comment: ""))
                }
            }
        }
        task.resume()
    }
}
