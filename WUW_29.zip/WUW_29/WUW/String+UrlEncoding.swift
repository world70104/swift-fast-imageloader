//
//  String+UrlEncoding.swift
//  WUW
//
//  A String extension that provides percent encoding of URL
//
//  Created by master on 7/19/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

extension String {
    public func stringUrlEncoding() -> String? {
    // url encoding
        let unreserved = ":/&=.?"
        var allowedCharacterSet =  NSCharacterSet.alphanumerics
        allowedCharacterSet.insert(charactersIn: unreserved)
        let newStrData = addingPercentEncoding(withAllowedCharacters: allowedCharacterSet as CharacterSet)
        return newStrData
    }
}
