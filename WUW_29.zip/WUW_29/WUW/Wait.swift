//
//  Wait.swift
//  wait
//
//  Created by admin on 2018/4/11.
//  Copyright © 2018 mmh. All rights reserved.
//

import Foundation
import UIKit

class Wait {
    // Variable
    var preBgColor:UIColor!
    var mWaitDlg:WaitView!
    var mParentView : UIView
    var msg : String
    var bgColor:UIColor!
    var fgColor:UIColor!

    init(mParentView : UIView, msg : String, bgColor:UIColor, fgColor:UIColor ) {
        self.mParentView = mParentView
        self.msg = msg
        self.bgColor = bgColor
        self.fgColor = fgColor
    }
    
    // method
    ////////////////////////////////////////////////////////////////////////
    // start wait
    //
    // inp: msg - message
    // out: none
    ////////////////////////////////////////////////////////////////////////
    func startWait()
    {
        preBgColor = mParentView.backgroundColor!;
        mParentView.backgroundColor = bgColor;
        mWaitDlg =
            WaitView( msg: msg, bkColor: fgColor )
        mWaitDlg.mParentView = mParentView
        mWaitDlg.tag = 100
        mParentView.addSubview(mWaitDlg)
    }
    ////////////////////////////////////////////////////////////////////////
    // stop wait
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////
    func stopWait()
    {
        mWaitDlg.remove()
        for view in mParentView.subviews
        {
            if ( view.tag == 100 )
            {
                view.removeFromSuperview()
                
            }
        }
        mParentView.backgroundColor = preBgColor
    }
}

// WaitView class
class WaitView: UIView {
    // variable
    var mParentView = UIView()
    // Indicator
    let mActivityIndicatorView =
        UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    // message
    let mMessageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
    ////////////////////////////////////////////////////////////////////////
    // init
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////
    init( msg:String, bkColor:UIColor ) {
        super.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        mMessageLabel.text = msg
        // background color
        backgroundColor = bkColor
        self.backgroundColor = backgroundColor
        self.layer.cornerRadius = 12.0
        // animation start
        mActivityIndicatorView.startAnimating()
        // text set
        mMessageLabel.font = UIFont.boldSystemFont(ofSize: UIFont.labelFontSize)
        mMessageLabel.textColor = UIColor.white
        mMessageLabel.textAlignment = .center
        mMessageLabel.shadowColor = UIColor.black
        mMessageLabel.shadowOffset = CGSize(width: 0.0, height: 1.0)
        mMessageLabel.numberOfLines = 0
        // Add the sub view
        addSubview(mActivityIndicatorView)
        addSubview(mMessageLabel)
    }
    ////////////////////////////////////////////////////////////////////////
    // init
    //
    // inp: coder - decode data
    // out: none
    ////////////////////////////////////////////////////////////////////////
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    ////////////////////////////////////////////////////////////////////////
    // sub view set
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////
    override func layoutSubviews() {
        super.layoutSubviews()
        let between:CGFloat = 20.0
        // Bounding box setting
        self.frame.size.width = 160.0
        self.frame.size.height = 160.0
        
        self.frame.origin.x =
            ( mParentView.frame.size.width - self.frame.size.width ) / 2
        self.frame.origin.y =
            ( mParentView.frame.size.height - self.frame.size.height ) / 2
        
        let messageLabelSize = mMessageLabel.sizeThatFits(CGSize(width: 160.0 - 20.0 * 2.0,
             height: Double(Float.greatestFiniteMagnitude)))
        mMessageLabel.frame.size.width = messageLabelSize.width
        mMessageLabel.frame.size.height = messageLabelSize.height
        
        // Indicator setting
        mActivityIndicatorView.frame.origin.x =
            (self.frame.size.width - mActivityIndicatorView.frame.size.width) / 2.0
        
        mActivityIndicatorView.frame.origin.y =
            ( self.frame.size.height - (mActivityIndicatorView.frame.size.height
                + mMessageLabel.frame.size.height + between ) ) / 2.0
        
        // Massage setting
        mMessageLabel.frame.origin.x =
            (self.frame.size.width - mMessageLabel.frame.size.width) / 2.0
        mMessageLabel.frame.origin.y =
            mActivityIndicatorView.frame.origin.y + mActivityIndicatorView.frame.size.height + between
    }
    ////////////////////////////////////////////////////////////////////////
    // remove sub view
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////
    func remove() {
        mActivityIndicatorView.removeFromSuperview()
        mMessageLabel.removeFromSuperview()
    }
}
