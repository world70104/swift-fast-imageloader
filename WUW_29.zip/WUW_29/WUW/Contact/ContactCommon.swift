//
//  ContactCommon.swift
//  WUW
//
//  Created by admin on 2018/4/23.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import Foundation
import UIKit
import Contacts

extension StringProtocol where Index == String.Index {
    func index<T: StringProtocol>(of string: T, options: String.CompareOptions = []) -> Index? {
        return range(of: string, options: options)?.lowerBound
    }
}

final class ContactCommon {

    // Can't init is singleton
    private init() { }

    // Shared Instance
    static let Shared = ContactCommon()

    // original contact
    var contacts = [CNContact]()
    
    // contact data for process
    var contactData = [ContactData]()
    
    // register contact count
    var registerContactCount = 0
    
    // contact data index
    var contactDataIndex = [Int]()
    
    // Key for contact file save flag
    static let KEY_CONTACT_FILE_SAVE = "key_contactFileSave"
    static let VALUE_CONTACT_FILE_SAVE = "YES"
    
    // contact file name
    let contactDataFlie = "_contact.json"

    // make the original index
    func makeOriginalContactDataIndex() {
        contactDataIndex = [Int]()
        let count = contactData.count
        for index in 0..<count {
            contactDataIndex.append(index)
        }
    }
    
    // get the phone number from APContact
    func contactPhones(_ contact :CNContact) -> [String] {
        var _mContactPhone = [String]()
        _mContactPhone.removeAll()
        for phone in contact.phoneNumbers {
            let phoneNumber = phone.value.stringValue
            if phoneNumber.count >= 2 {
                // remove expect number & +
                let number = phoneNumber.filter{"1234567890+".contains($0)}
                // check country code
                var newNumber = number
                if number.prefix(2) == "00" {
                    // "00" - > "+"
                    newNumber = number.replacingCharacters(
                        in: number.startIndex..<number.index(number.startIndex,
                        offsetBy: 2), with: "+")
                }
                else if number.prefix(1) != "+" {
                    newNumber = Common.Shared.myProfileData.mCountryCode + number
                }
                _mContactPhone.append(newNumber)
            }
        }
        return _mContactPhone
    }
    
    // Save the contact data
    func saveContactDataFile(viewController:UIViewController?, tableviewController:UITableViewController?) {
        // Item Save
        // contact data to JSON encoder
        let jsonEncoder = JSONEncoder()
        jsonEncoder.outputFormatting = .prettyPrinted
        let jsonData = try? jsonEncoder.encode(ContactCommon.Shared.contactData)
        // show the json data
        if let jsonString = String(data: jsonData!, encoding: .utf8) {
            print(jsonString)
        }
        // file write the JSON
        let fileManager = FileManager.default
        var fileURL:URL!
        // get the URL
        let documentDirectory = try? fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor:nil, create:false)
        fileURL = documentDirectory?.appendingPathComponent(ContactCommon.Shared.contactDataFlie)
        // write the data file
        do {
            try jsonData!.write(to: fileURL)
            // Set the contact file save flag
            let pList = UserDefaults.standard
            pList.set( ContactCommon.VALUE_CONTACT_FILE_SAVE,
                       forKey:ContactCommon.KEY_CONTACT_FILE_SAVE )
        }
        catch {
            Common.Shared.alertMessage(viewController:viewController,
                tableviewController:tableviewController,
                message: NSLocalizedString("Failed to write file", comment: ""))
            print("Failed to write JSON data: \(error.localizedDescription)")
        }
/*
        // save the contact photo
        for index in 0..<contactData.count {
            let oneConatctData = contactData[index]
            Common.Shared.readImageFileFromServer(path: oneConatctData.photoUrl)
        }
 */
    }
    
    // Load the contact data
    func readContactDataFile(viewController:UIViewController?, tableviewController:UITableViewController?) {
        // firl read the JSON
        let fileManager = FileManager.default
        let documentDirectory = try? fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor:nil, create:false)
        do {
            // file write the JSON
            var fileURL:URL!
            // get the URL
            fileURL = documentDirectory?.appendingPathComponent(ContactCommon.Shared.contactDataFlie)
            // Read
            let data = try Data(contentsOf: fileURL, options: .mappedIfSafe)
            ContactCommon.Shared.contactData =
                try JSONDecoder().decode([ContactData].self, from: data)
            print(ContactCommon.Shared.contactData)
            // get the register user count
            getRegisterContactCount()
        } catch {
            Common.Shared.alertMessage(viewController:viewController,
                tableviewController:tableviewController,
                message: NSLocalizedString("Failed to read file", comment: ""))
            print("Failed to read JSON data: \(error.localizedDescription)")
        }
    }
    
    // get the register contact count
    func getRegisterContactCount() {
        registerContactCount = 0
        for oneContactData in contactData {
            if oneContactData.statusRegister != 0 {
                registerContactCount += 1
            }
        }
    }
}
