//
//  ContactCell.swift
//  WUW
//
//  Created by POLARIS on 04/21/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

class ContactCell: UITableViewCell {
    
    @IBOutlet var photoView: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var detailLabel: UILabel!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var inviteButton: UIButton!
}
