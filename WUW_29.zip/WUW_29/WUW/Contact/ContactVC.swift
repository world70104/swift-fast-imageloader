//
//  SecondVC.swift
//  Sample
//
//  Created by POLARIS on 01/17/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit
import MessageUI
import Kingfisher

struct FailableDecodable<Base : Decodable> : Decodable {
    
    let base: Base?
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        self.base = try? container.decode(Base.self)
    }
}

class ContactVC: UITableViewController, MFMessageComposeViewControllerDelegate {
    var mvc : MainViewController!
    
    var section = [String]()

    // wait dlg for contact request
    var mwait:Wait!
    
    // selected index( show row )
    var mSeletedRow = 0
    // selected real index in contact data
    var mSeletedRealIndex = 0
    
    var mDispatchGroup = DispatchGroup()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ContactCommon.Shared.contactDataIndex.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let index = ContactCommon.Shared.contactDataIndex[indexPath.row]
        // status
        // 0 - No contact data detail( contact's WL data )
        let status = ContactCommon.Shared.contactData[index].statusRegister
        
        let cellId = status != 0 ? "ContactCell" : "ContactInviteCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId) as! ContactCell
        // load the image
        cell.photoView.image = UIImage(named: "empty_profile.png" )
        if ContactCommon.Shared.contactData[index].photoUrl.count != 0 {
            cell.photoView.kf.indicatorType = .activity
            cell.photoView.kf.setImage(
                with: URL(string: Common.SERVER_URL + ContactCommon.Shared.contactData[index].photoUrl ),
                placeholder: nil)
        }
        cell.photoView.layer.cornerRadius = cell.photoView.frame.width / 2
        cell.photoView.layer.masksToBounds = true
        cell.nameLabel.text = ContactCommon.Shared.contactData[index].name

        if status != 0 {
            // get the WL name
            cell.detailLabel.text = ""
            let contactWLDatas = ContactCommon.Shared.contactData[index].contactWLData
            // get the wl data count
            let count = contactWLDatas.count
            let signupButtonText = String(count) + NSLocalizedString(" items into his/her wishlist", comment: "")
            cell.detailLabel.text! = signupButtonText
            
            // get the birthday
            cell.dateLabel.text = ContactCommon.Shared.contactData[index].birthday
            
        } else {
            cell.inviteButton.tag = indexPath.row
            cell.inviteButton.addTarget(self, action: #selector(inviteClk(_:)), for: .touchUpInside)
        }

        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let index = ContactCommon.Shared.contactDataIndex[indexPath.row]
        // status
        // 0 - No contact data detail( contact's WL data )
        let status = ContactCommon.Shared.contactData[index].statusRegister
        if status != 0 {
            mSeletedRealIndex = index
            getOneContact()
/*
            if ContactCommon.Shared.contactData[index].contactWLData.count != 0 {
                guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "WishVC") as? WishViewControlloer else {
                    return
                }
                uvc.index = index
                self.present(uvc, animated: false)
                print("You selected cell #\(indexPath.row)!")
            }
 */
        }
    }
    
    // get the one contact data
    func getOneContact() {
        // Make the request
        let url = URL(string: Common.SERVER_URL + "users.php?options=get_user_data")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // body
        let postString = Common.KEY_USER_ID + "=" + ContactCommon.Shared.contactData[self.mSeletedRealIndex].id
        request.httpBody = postString.data(using: .utf8)
        // ready the wait
        mwait = Wait(mParentView:self.mvc.view, msg:NSLocalizedString("Loading wishlist…", comment: ""),
                     bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                     fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
        mwait.startWait()
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 1
                if data != nil {
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    check = 0
                                    // uer info
                                    let userinfoJson = json["userinfo"] as? [String: Any]
                                    self.LoadUserInfo( userinfoJson : userinfoJson! )
                                    // wish list
                                    // wish list data
                                    let wishlistJson = json["wishlist"] as? [[String: Any]]
                                    // get the invite data
                                    self.LoadWlData( wishlistJson:wishlistJson!)
                                }
                                
                            } else {  // fail?
                                print("failure")
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                // Stop the wait
                if check != 0 {
                    self.mwait.stopWait()
                    if check == 1 {
                        Common.Shared.alertMessage(viewController:nil,
                            tableviewController:self,
                            message: NSLocalizedString("Failed.", comment: "") )
                    } else {
                        Common.Shared.alertMessage(viewController:nil,
                            tableviewController:self,
                            message: NSLocalizedString("Server is busy now.", comment: ""))
                    }
                }
            }
        }
        task.resume()
    }
    
    // Load the update user info
    func LoadUserInfo( userinfoJson : [String: Any] ) {
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].photoUrl =
            userinfoJson["photo_url"] as! String
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].birthday =
            userinfoJson["birthday"] as! String
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].device_id =
            userinfoJson["device_id"] as! String
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].block =
            userinfoJson["block"] as! String
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].country_code =
            userinfoJson["country_code"] as! String
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].created_at =
            userinfoJson["created_at"] as! String
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].id =
            userinfoJson["id"] as! String
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].phone.removeAll()
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].phone.append(
            userinfoJson["phone_number"] as! String
        )
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].block_phoneNumbers.removeAll()
        let _blockPhoneNumbers = (userinfoJson["block_phoneNumbers"] as? String)!
        let data = Data(_blockPhoneNumbers.utf8)
        do {
            let blockPhoneNumbers = try JSONSerialization.jsonObject(with: data) as! [String]
            for blockPhoneNumber in blockPhoneNumbers {
                ContactCommon.Shared.contactData[self.mSeletedRealIndex].block_phoneNumbers.append(blockPhoneNumber)
            }
        } catch {
            print(error)
        }
    }
    
    func LoadWlData( wishlistJson:[[String: Any]] ) {
        ContactCommon.Shared.contactData[self.mSeletedRealIndex].contactWLData.removeAll()
        for value in wishlistJson {
            ContactCommon.Shared.contactData[self.mSeletedRealIndex].contactWLData.append(
                ContactWLData(
                    id: (value["id"] as? String)!,
                    owner_id: (value["owner_id"] as? String)!,
                    name: (value["name"] as? String)!,
                    photo_url: (value["photo_url"] as? String)!,
                    price: (value["price"] as? String)!,
                    rating: (value["rating"] as? String)!,
                    description: (value["description"] as? String)!,
                    status: (value["status"] as? String)!,
                    orderer_id: (value["orderer_id"] as? String)!,
                    created_at: (value["created_at"] as? String)!
            ))
        }
        // download all file ?
        self.mDispatchGroup.notify(queue: .main) {
            // save file
            ContactCommon.Shared.saveContactDataFile( viewController:nil,
                                                      tableviewController:self)
            // end the data download
            self.mwait.stopWait()
            // block phone number check ?
            var check = false
            if ContactCommon.Shared.contactData[self.mSeletedRealIndex].block_phoneNumbers.count != 0 {
                for phoneNumber in ContactCommon.Shared.contactData[self.mSeletedRealIndex].block_phoneNumbers {
                    if phoneNumber == Common.Shared.myProfileData.mPhoneNumber {
                        check = true
                        break
                    }
                }
            }
            if check == false {
                if ContactCommon.Shared.contactData[self.mSeletedRealIndex].contactWLData.count != 0 {
                    guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "WishVC") as? WishViewControlloer else {
                        return
                    }
                    uvc.index = self.mSeletedRealIndex
                    self.present(uvc, animated: false)
                }
            }
            else {
                // "block" phone
                let alert = UIAlertController(title: nil,
                        message: NSLocalizedString("You have no permission.", comment: ""),
                        preferredStyle: .alert)
                let cancelAction = UIAlertAction(
                    title: NSLocalizedString("Ok", comment: ""),
                    style: .cancel){ (_) in
                        return
                }
                alert.addAction(cancelAction)
                self.present(alert, animated: false, completion: nil)
            }
        }
    }

    // invite event
    @objc func inviteClk(_ sender: UIButton) {
        // invite event
        print(sender.tag)
        mSeletedRow = sender.tag
        // get the real index
        mSeletedRealIndex = ContactCommon.Shared.contactDataIndex[mSeletedRow]
        // get the phone number
        let phoneNumbers = ContactCommon.Shared.contactData[mSeletedRealIndex].phone
        // phone number check
        if phoneNumbers.count == 0 {
            // No phone number
            Common.Shared.alertMessage(viewController:nil,
                tableviewController:self,
                message: NSLocalizedString("No phone number", comment: ""))
            return
        }
        // get the phone number
        var phoneNumberStr = ""
        for phoneNumber in phoneNumbers {
            phoneNumberStr += phoneNumber + ","
        }
        phoneNumberStr.remove(at: phoneNumberStr.index(before: phoneNumberStr.endIndex))
        if (MFMessageComposeViewController.canSendText()) {
            let controller = MFMessageComposeViewController()

            // make message body
            var bodyStr = NSLocalizedString("Hi,", comment: "")
            bodyStr += ContactCommon.Shared.contactData[mSeletedRealIndex].name
            bodyStr += NSLocalizedString("I have got one good app.", comment: "")
            controller.body = bodyStr
            
            controller.recipients = [phoneNumberStr]
            controller.messageComposeDelegate = self
            self.present(controller, animated: true, completion: nil)
        }
    }

    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        print("End")
        self.dismiss(animated: true, completion: nil)
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    func sortContactDataByRegister() {
        // get the modify data
        let modifiedData = ContactCommon.Shared.contactData[mSeletedRealIndex]
        // remove at original
        ContactCommon.Shared.contactData.remove(at: mSeletedRealIndex)
        // insert the register end
        ContactCommon.Shared.contactData.insert(modifiedData, at: ContactCommon.Shared.registerContactCount)
        // inc counter
        ContactCommon.Shared.registerContactCount += 1
        // sort the register contact
        let registerContactData =
            ContactCommon.Shared.contactData[0..<ContactCommon.Shared.registerContactCount]
        let sortedRegisterContactData = registerContactData.sorted{$0.name < $1.name}
        let allCount = ContactCommon.Shared.contactData.count
        // get the un-registered contact
        let unRegisterContactData =
            ContactCommon.Shared.contactData[
                ContactCommon.Shared.registerContactCount..<allCount]
        ContactCommon.Shared.contactData = sortedRegisterContactData + unRegisterContactData
        
        // re-search
        self.mvc.searchContactDataAfterInvite()
        
        // get the added register Contactor row
        for ix in 0..<ContactCommon.Shared.contactDataIndex.count {
            let rIndex = ContactCommon.Shared.contactDataIndex[ix]
            if ContactCommon.Shared.contactData[rIndex].name == modifiedData.name {
                let row = ContactCommon.Shared.contactDataIndex[ix]
                let _index = IndexPath(row: row, section: 0)
                self.tableView.scrollToRow(at: _index, at: UITableViewScrollPosition.middle, animated: true)
                break
            }
        }
    }
}
