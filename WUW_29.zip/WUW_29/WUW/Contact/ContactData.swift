//
//  ContactData.swift
//  WUW
//
//  Created by admin on 2018/4/23.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import Foundation

struct ContactWLData: Codable {
    let id: String
    let owner_id: String
    let name: String
    let photo_url: String
    let price: String
    let rating: String
    let description: String
    var status: String
    let orderer_id: String
    let created_at: String
    // init
    init(
        id: String,
        owner_id: String,
        name: String,
        photo_url: String,
        price: String,
        rating: String,
        description: String,
        status: String,
        orderer_id: String,
        created_at: String
        ) {
        self.id = id
        self.owner_id = owner_id
        self.name = name
        self.photo_url = photo_url
        self.price = price
        self.rating = rating
        self.description = description
        self.status = status
        self.orderer_id = orderer_id
        self.created_at = created_at
    }
}

struct ContactData: Codable {
    let name: String
    var phone: [String]
    // status : 0 - No register
    //          1 - regigster
    var statusRegister = 0
    var photoUrl = ""
    
    // data from server start
    var birthday = ""
    var block = "0";
    var block_phoneNumbers = [String]();
    var country_code = "";
    var created_at = "";
    var device_id = "";
    var id = "";
    // data from server end
    
    var contactWLData = [ContactWLData]()
    // init
    init(
        name: String,
        phone: [String]
        ) {
        self.name = name
        self.phone = phone
    }
}
