//
//  WishDetailViewController.swift
//  WUW
//
//  Created by POLARIS on 04/25/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

class WishDetailViewController: UIViewController {

    @IBOutlet var wishNameLabel: UILabel!
    @IBOutlet var wishRatingview: CosmosView!
    @IBOutlet var wishPriceLabel: UILabel!
    @IBOutlet var wishDescription: UITextView!
    @IBOutlet var button: UIButton!
    @IBOutlet weak var wishPhoto: UIImageView!
    
    var mWishViewControlloer:WishViewControlloer!
    var mContactWLData:ContactWLData!
    var isButtonClick = false
    
    var preStatus = ""
    // contact data real index
    var index = 0
    // selected contact data detail index
    var detailIndex = -1
    
    var photoImage:UIImage!
    // wait dlg for image upload request
    var mwait:Wait!

    override func viewDidLoad() {
        super.viewDidLoad()

        wishNameLabel.text = mContactWLData.name
        wishRatingview.rating = Double(mContactWLData.rating)!
        wishPriceLabel.text = mContactWLData.price
        wishDescription.text = mContactWLData.description
        wishRatingview.isUserInteractionEnabled = false
        // button radius set
        button.layer.cornerRadius = 10
        // pre status
        preStatus = mContactWLData.status
        // block status
        // loc ?
        if mContactWLData.status == "0" {
            
            button.setTitle( NSLocalizedString("Block Iterm", comment: ""), for: .normal )
            button.backgroundColor = UIColor(red: 7/255, green: 92/255, blue: 85/255, alpha: 1)
        }
        else if mContactWLData.status == "1" {
            button.setTitle( NSLocalizedString("Confirm Purchase", comment: ""), for: .normal)
            button.backgroundColor = UIColor(red: 126/255, green: 0, blue: 1/255, alpha: 1)
        }
        wishPhoto.image = photoImage
    }

    override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {
        super.dismiss(animated: flag, completion: completion)
        // alert dismiss ?
        if isButtonClick {
            isButtonClick = false
            updateWl()
        }
    }
    
    @IBAction func goBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
        // status modify ?
/*
        if preStatus != mContactWLData.status {
            ContactCommon.Shared.contactData[index].contactWLData[detailIndex].status =
                mContactWLData.status
            ContactCommon.Shared.saveContactDataFile(viewController:self, tableviewController:nil)
        }
 */
    }
    
    @IBAction func buttonClk(_ sender: Any) {
        isButtonClick = true
        if mContactWLData.status == "0" {
            button.setTitle( NSLocalizedString("Confirm Purchase", comment: ""), for: .normal)
            button.backgroundColor = UIColor(red: 126/255, green: 0, blue: 1/255, alpha: 1)
            
            //  alert
            Common.Shared.alertMessage(viewController:self,
                tableviewController:nil,
                message: NSLocalizedString("Thanks for locking the item!", comment: ""))
            mContactWLData.status = "1"
        }
        else if mContactWLData.status == "1" {
            //  alert
            Common.Shared.alertMessage(viewController:self,
                tableviewController:nil,
                message: NSLocalizedString("Thanks for purchasing the item!", comment: "") )
            mContactWLData.status = "2"
        }
    }
    
    
    // update the wl data
    func updateWl() {
        // Make the request
        let url = URL(string: Common.SERVER_URL + "users.php?options=update_wish_list")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // body
        var postString = Common.KEY_ID + "=" + mContactWLData.id + "&"
        postString += Common.KEY_ORDERER_ID + "=" + mContactWLData.orderer_id + "&"
        postString += Common.KEY_STATUS + "=" + mContactWLData.status
        
        request.httpBody = postString.data(using: .utf8)
        // ready the wait
        mwait = Wait(mParentView:self.view, msg:NSLocalizedString("Updating wishlist…", comment: ""),
                     bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                     fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
        mwait.startWait()
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 0
                if data != nil {
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                }
                                else {
                                    print("Updating wishlist request failure")
                                    check = 2
                                }
                                
                            } else {  // fail?
                                print("Updating wishlist request failure")
                                check = 2
                            }
                        }
                    } catch {
                        print("server error")
                        check = 3
                    }
                } else {
                    print("network error")
                    check = 4
                }
                self.mwait.stopWait()
                // Stop the wait
                if check == 0 {
                    ContactCommon.Shared.contactData[self.index].contactWLData[self.detailIndex].status =
                        self.mContactWLData.status
                    ContactCommon.Shared.saveContactDataFile(viewController:self, tableviewController:nil)
                    self.dismiss(animated: true, completion: nil)
                }
                else if check == 2 {
                        Common.Shared.alertMessage(viewController:self,
                            tableviewController:nil, message: "Updating wishlist request failure")
                }
                else if check > 2 {
                        Common.Shared.alertMessage(viewController:self,
                            tableviewController:nil, message: "Network failure")
                }
            }
        }
        task.resume()
    }
}


