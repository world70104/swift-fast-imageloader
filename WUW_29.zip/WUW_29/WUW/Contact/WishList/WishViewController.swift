//
//  SecondVC.swift
//  Sample
//
//  Created by POLARIS on 01/17/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

class WishViewControlloer: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var personNameLabel: UILabel!
    @IBOutlet var wishTableView: UITableView!
    
    // contact data real index
    var index = 0
    // selected contact data detail index
    var detailIndex = -1
    
    override func viewDidLoad() {
        personNameLabel.text = ContactCommon.Shared.contactData[index].name
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // come in detail view ?
        wishTableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return ContactCommon.Shared.contactData[index].contactWLData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WishCell") as! WishCell
        
        let mContactWLData = ContactCommon.Shared.contactData[index].contactWLData[indexPath.row]
        // read the  image file
        cell.photo.kf.indicatorType = .activity
        cell.photo.kf.setImage(
            with: URL(string: Common.SERVER_URL + mContactWLData.photo_url ),
            placeholder: nil)
        // name
        cell.nameLabel.text = mContactWLData.name
        // price
        cell.priceLable.text = mContactWLData.price
        // item status
        if mContactWLData.status == "1" {
            cell.state.image = UIImage(named: "item_lock")
        } else if mContactWLData.status == "0" {
            cell.state.image = UIImage(named: "item_unlock")
        } else if mContactWLData.status == "2" {
            cell.state.image = UIImage(named: "item_gift")
        }
        // rating
        cell.star.rating = Double(mContactWLData.rating)!
        cell.star.isUserInteractionEnabled = false
        
        return cell
    }

    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if ContactCommon.Shared.contactData[index].contactWLData[indexPath.row].status == "2" {
            //  alert
            let alert = UIAlertController(title: nil, message: NSLocalizedString("This item has already been bought / given!", comment: ""), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true)
        }
        else if ( ( ContactCommon.Shared.contactData[index].contactWLData[indexPath.row].status == "1" ) &&
            ( ContactCommon.Shared.contactData[index].contactWLData[indexPath.row].orderer_id != Common.Shared.myProfileData.mUserID )
            )
        {
            //  alert
            let alert = UIAlertController(title: nil, message: NSLocalizedString("Sorry, this item is locked by another user.", comment: ""), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true)
        }
        else {
            guard let uvc = self.storyboard?.instantiateViewController(withIdentifier: "WishDetailVC") as? WishDetailViewController else {
                return
            }
            // selected detail index
            detailIndex = indexPath.row
            uvc.mWishViewControlloer = self
            uvc.index = index
            uvc.detailIndex = detailIndex
            uvc.mContactWLData = ContactCommon.Shared.contactData[index].contactWLData[indexPath.row]
            let cell = tableView.cellForRow(at: indexPath) as! WishCell
            uvc.photoImage = cell.photo.image
            self.present(uvc, animated: false)
            print("You selected cell #\(indexPath.row)!")
        }
    }
    
    @IBAction func goBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
