//
//  WishListCell.swift
//  WUW
//
//  Created by POLARIS on 04/21/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

class WishCell: UITableViewCell {
    
    @IBOutlet var photo: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var priceLable: UILabel!
    @IBOutlet var state: UIImageView!
    @IBOutlet var star: CosmosView!
}
