//
//  AppDelegate.swift
//  WUW
//
//  Created by POLARIS on 04/20/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import Contacts

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    // server register phone number
    var serverRegisterPhone = [String]()
    
    // equal contact phone in server register phone number
    var serverContactPhone = [String]()
    var contactPhoneIndexWithServerPhone = [Int]()
    
    // contact data for process
    var contactDataForRegister = [ContactData]()
    var contactDataForNoRegister = [ContactData]()

    //  flag for manual contact update
    // true - manual contact update
    // false - no
    var isContactUpdate = false
    
    var objMainViewController: MainViewController?
    var objViewController: ViewController?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        objMainViewController = nil
        //get country code
        Common.Shared.mCurrentCountryName = (Locale.current as NSLocale).object(forKey: .countryCode) as? String
        if Common.Shared.mCurrentCountryName != nil {
            Common.Shared.mCurrentCountryCode =
                getCountryCodeOrName(_countryName: (Common.Shared.mCurrentCountryName)!, _countryCode:"")!
            if Common.Shared.mCurrentCountryCode.count != 0 {
                Common.Shared.mCurrentCountryCode = "+" + Common.Shared.mCurrentCountryCode
            }
        }
        Common.Shared.myProfileData.mCountryCode = Common.Shared.mCurrentCountryCode
        
        // Override point for customization after application launch.
        IQKeyboardManager.shared.enable = true
        
        // check the parameter
        let pList = UserDefaults.standard
        // if contact data file  present?
        let check = pList.string(forKey:ContactCommon.KEY_CONTACT_FILE_SAVE)
        // if present?
        if check != nil {
            // Read the contact data
            ContactCommon.Shared.readContactDataFile(viewController: nil, tableviewController: nil)
            
            // make the contact data index
            ContactCommon.Shared.makeOriginalContactDataIndex()
            
            // goto mainview
            self.window = UIWindow(frame: UIScreen.main.bounds)
            let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            // check the parameter
            let pList = UserDefaults.standard
            // check the parameter
            let checkID = pList.string(forKey:Common.KEY_PROFILE_FILE_SAVE)
            // if present?
            if checkID != nil {
                // Load the parameter
                Common.Shared.readMyProfileDataFile(viewController: nil, tableviewController: nil)
                // go to MainVC
                guard let uvc = mainStoryboard.instantiateViewController(withIdentifier: "MainVC") as? MainViewController else {
                    return true
                }
                self.window?.rootViewController = uvc
            }
            else {
                // go to Signin
                guard let uvc = mainStoryboard.instantiateViewController(withIdentifier: "SignInVC") as? MainViewController else {
                    return true
                }
                self.window?.rootViewController = uvc
            }
            
            self.window?.makeKeyAndVisible()
        }
        else {
//            getRegisterPhoneNumberFromServer()
        }
        
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    func getRegisterPhoneNumberFromServer() {
        let url = URL(string: Common.SERVER_URL + "users.php?options=registered_phone_numbers")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                if data != nil {
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    print("success")
                                    // get the phone number
                                    let serverRegisterPNs = json["phone_numbers"] as? [[String:Any]]
                                    for serverRegisterPN in serverRegisterPNs! {
                                        let pn = serverRegisterPN["phone_number"] as? String
                                        print(pn!)
                                        self.serverRegisterPhone.append(pn!)
                                    }
                                    
                                    // load the contact
                                    self.loadContacts()
                                } else {  // fail?
                                    print("server error")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                    }
                } else {
                    print("network error")
                }
            }
        }
        task.resume()
    }
}

// Load the all contact in phone
extension AppDelegate {
    // load the contact
    func loadContacts() {
        // No the manual contact update ?
        if isContactUpdate == false {
            // check the parameter
            let pList = UserDefaults.standard
            // if contact data file  present?
            let check = pList.string(forKey:ContactCommon.KEY_CONTACT_FILE_SAVE)
            // if present?
            if check != nil {
                // Read the contact data
                ContactCommon.Shared.readContactDataFile(viewController: nil, tableviewController: nil)
                
                // make the contact data index
                ContactCommon.Shared.makeOriginalContactDataIndex()
                
                return
            }
        }
        else {
            isContactUpdate = false
        }
        // load the contact for phone
        let store = CNContactStore()
        store.requestAccess(for: .contacts, completionHandler: {
            granted, error in
            guard granted else {
                let alert = UIAlertController(title: "Can't access contact", message: "Please go to Settings -> MyApp to enable contact permission", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))

                if self.objViewController != nil {
                    self.objViewController?.present(alert, animated: true, completion: nil)
                }
                else {
                    self.objMainViewController?.present(alert, animated: true, completion: nil)
                }
                return
            }
            // get the contacts
            let keysToFetch = [CNContactFormatter.descriptorForRequiredKeys(for: .fullName), CNContactPhoneNumbersKey] as [Any]
            let request = CNContactFetchRequest(keysToFetch: keysToFetch as! [CNKeyDescriptor])
            ContactCommon.Shared.contacts = [CNContact]()
            do {
                try store.enumerateContacts(with: request){
                    (contact, cursor) -> Void in
                    ContactCommon.Shared.contacts.append(contact)
                }
            } catch let error {
                print("Fetch contact error: \(error)")
            }
            // pre-data remove all
            ContactCommon.Shared.contactData.removeAll()
            self.serverContactPhone.removeAll()
            self.contactPhoneIndexWithServerPhone.removeAll()
            self.contactDataForRegister.removeAll()
            self.contactDataForNoRegister.removeAll()
            // load by one contact
            var indexContacts = 0
            for contact in ContactCommon.Shared.contacts {
                let name = CNContactFormatter.string(from: contact, style: .fullName)
                let phones = ContactCommon.Shared.contactPhones(contact)
                let _contactData =  ContactData( name:name!, phone:phones )
                //  ContactCommon.Shared.contactData.append( _contactData )
                var registerFlag = false
                for phone in phones {
                    let indexOfA = self.serverRegisterPhone.index(of: phone)
                    // compare the phone number
                    if indexOfA != nil {
                        self.serverContactPhone.append(phone)
                        registerFlag = true
                        break
                    }
                }
                if registerFlag {
                    self.contactDataForRegister.append(_contactData)
                    self.contactPhoneIndexWithServerPhone.append(indexContacts)
                    indexContacts += 1
                }
                else {
                    self.contactDataForNoRegister.append(_contactData)
                }
            }
            self.sendCompPhoneNumber()
        })
    }
    
    func getCountryCodeOrName(_countryName:String, _countryCode:String)->String?{
        
        // get the country code
        if _countryCode == "" {
            let countryCode = Common.Shared.countryNameCodes[_countryName]
            Common.Shared.myProfileData.mCountryName = _countryName
            return countryCode
        }
        
        // get the country name
        var countryName = ""
        var countryCode = _countryCode
        countryCode.remove(at: countryCode.startIndex)
        for countryNameCode in Common.Shared.countryNameCodes.values {
            if countryNameCode == countryCode {
                countryName = "Present"
                break
            }
        }
        return countryName
    }

    func sendCompPhoneNumber() {
        // present same phone?
        let count = self.serverContactPhone.count
        if count != 0 {
            let url = URL(string: Common.SERVER_URL + "users.php?options=refresh_contact")
            var request = URLRequest(url:url!)
            // header
            request.httpMethod = "POST"
            // body
            var postString = "arr_phone_number" + "=["
            // make body by array
            var index = 0
            for param in self.serverContactPhone{
                let possibleNumberStr = param.replacingOccurrences(of: "+", with: "%2B")
                // " symbole
                postString += "%22" + possibleNumberStr + "%22"
                index += 1
                if index != count {
                    // , symbole
                    postString += "%2c"
                }
            }
            postString += "]"

            request.httpBody = postString.data(using: .utf8)
            // send request
            let task = URLSession.shared.dataTask(with: request) {
                (data: Data?, response: URLResponse?, error: Error?) in
                DispatchQueue.main.async() {
                    var check = 0
                    if data != nil {
                        do {
                            // signin fail
                            check = 1
                            if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                            {
                                print(json)
                                if let result = json["result"] as? String {
                                    // success?
                                    if result == "success" {
                                        print("success")
                                        check = 0
                                        let usersinfoJson = json["connected_users_info"] as? [[String: Any]]
                                        for userinfoJson in usersinfoJson! {
                                            // get the data for one phone
                                            self.getOneData( json:userinfoJson )
                                        }
                                    } else {  // fail?
                                        print("signin failure")
                                    }
                                }
                            }
                        } catch {
                            print("server error")
                            check = 2
                        }
                    } else {
                        print("network error")
                        check = 3
                    }
                    
                    // get the register user count
                    ContactCommon.Shared.getRegisterContactCount()
                    
                    // Save the contact data
                    var newData = self.contactDataForRegister.sorted{ $0.name < $1.name }
                    self.contactDataForRegister = newData
                    newData = self.contactDataForNoRegister.sorted{ $0.name < $1.name }
                    self.contactDataForNoRegister = newData

                    ContactCommon.Shared.contactData =
                        self.contactDataForRegister + self.contactDataForNoRegister
                    
                    ContactCommon.Shared.saveContactDataFile(viewController: nil, tableviewController: nil)
                    
                    // remove original data
                    ContactCommon.Shared.contacts.removeAll()
                    
                    // make the contact data index
                    ContactCommon.Shared.makeOriginalContactDataIndex()
                    
                    if self.objMainViewController != nil {
                        // load table view
                        // Reload the contact table view for mainview
                        self.objMainViewController?.ContactVC.tableView.reloadData()
                        self.objMainViewController?.mwait.stopWait()
                    }
                }
            }
            task.resume()
        }
        // No the same phone number
        else {
            if self.objMainViewController != nil {
                // load table view
                // Reload the contact table view for mainview
                self.objMainViewController?.ContactVC.tableView.reloadData()
                self.objMainViewController?.mwait.stopWait()
            }
        }
    }
    
    func getOneData( json:[String: Any] ) {
        // user information
        let connectUser = json["connected_user"] as Any
        let ConnectUsers = connectUser as? [[String: Any]]
        let newConnectUser = ConnectUsers![0] as [String: Any]
        
        let birthday = newConnectUser["birthday"] as? String
        let block = newConnectUser["block"] as? String
        let block_phoneNumbers = newConnectUser["block_phoneNumbers"] as? ([String])
        if block_phoneNumbers != nil {
            for block_phoneNumber in block_phoneNumbers! {
                print(block_phoneNumber)
            }
        }
        let country_code = newConnectUser["country_code"] as? String
        let created_at = newConnectUser["created_at"] as? String
        let device_id = newConnectUser["device_id"] as? String
        let id = newConnectUser["id"] as? String
        let phone_number = newConnectUser["phone_number"] as? String
        let photo_url = newConnectUser["photo_url"] as? String
        // check phonenumber
        let indexOfA = self.serverContactPhone.index(of: phone_number!)
        // compare the phone number
        if indexOfA != nil {
            // get the index
            let index = self.contactPhoneIndexWithServerPhone[indexOfA!]
            self.contactDataForRegister[index].birthday = birthday!
            self.contactDataForRegister[index].block = block!
            if block_phoneNumbers != nil {
                self.contactDataForRegister[index].block_phoneNumbers = block_phoneNumbers!
            }
            else {
                self.contactDataForRegister[index].block_phoneNumbers = []
            }
            self.contactDataForRegister[index].country_code = country_code!
            self.contactDataForRegister[index].created_at = created_at!
            self.contactDataForRegister[index].device_id = device_id!
            self.contactDataForRegister[index].id = id!
            self.contactDataForRegister[index].phone.removeAll()
            self.contactDataForRegister[index].phone.append(phone_number!)
            self.contactDataForRegister[index].photoUrl = photo_url!
            
            self.contactDataForRegister[index].statusRegister = 1

            // wishlist information    contactWLData
            self.contactDataForRegister[index].contactWLData.removeAll()
            let connectWishlists = json["connected_wishlist"] as Any
            let newConnectWishlists = connectWishlists as! ([[String:Any]])
            for newConnectWishlist in newConnectWishlists {
                let oneContactWLData = ContactWLData(
                    id: (newConnectWishlist["id"] as? String)!,
                    owner_id: (newConnectWishlist["owner_id"] as? String)!,
                    name: (newConnectWishlist["name"] as? String)!,
                    photo_url: (newConnectWishlist["photo_url"] as? String)!,
                    price: (newConnectWishlist["price"] as? String)!,
                    rating: (newConnectWishlist["rating"] as? String)!,
                    description: (newConnectWishlist["description"] as? String)!,
                    status: (newConnectWishlist["status"] as? String)!,
                    orderer_id: (newConnectWishlist["orderer_id"] as? String)!,
                    created_at: (newConnectWishlist["created_at"] as? String)!
                )
                self.contactDataForRegister[index].contactWLData.append(oneContactWLData)
            }
        }
    }
}

extension Array where Element: Equatable {
    func indexes(of element: Element) -> [Int] {
        return self.enumerated().filter({ element == $0.element }).map({ $0.offset })
    }
}
