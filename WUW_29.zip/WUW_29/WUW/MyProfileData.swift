//
//  MyProfileData.swift
//  WUW
//
//  Created by admin on 2018/5/11.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import Foundation

struct MyProfileData: Codable {
    var mUUID: String
    var mPhoneNumber: String
    var mBirthday: String
    var mCountryName: String
    var mCountryCode: String
    var mUserID: String
    var mPhoto_url: String
    var mBlockPhoneNumbers:[String]
    // init
    init(
        uuid: String? = nil, //👈
        phoneNumber: String? = nil,
        birthday: String? = nil,
        countryName: String? = nil,
        countryCode: String? = nil,
        mUserID: String? = nil
        ) {
        self.mUUID = uuid!
        self.mPhoneNumber = phoneNumber!
        self.mBirthday = birthday!
        self.mCountryName = countryName!
        self.mCountryCode = countryCode!
        self.mUserID = mUserID!
        self.mPhoto_url = ""
        self.mBlockPhoneNumbers = []
    }
}
