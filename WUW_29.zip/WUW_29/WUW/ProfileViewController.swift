//
//  ProfileViewController.swift
//  WUW
//
//  Created by POLARIS on 04/21/18.
//  Copyright © 2018 POLARIS. All rights reserved.
//

import UIKit

extension Data {
    mutating func append(string: String) {
        let data = string.data(
            using: String.Encoding.utf8,
            allowLossyConversion: true)
        append(data!)
    }
}

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet var profileImage: UIImageView!
    @IBOutlet var addImageButton: UIButton!
    @IBOutlet var birthdayLabel: UILabel!
    @IBOutlet var phoneLabel: UILabel!
    @IBOutlet weak var txtDatePicker: UITextField!
    
    // birthday picker
    let datePicker = UIDatePicker()
    var loadNewBirthday = ""
    
    // image oicker
    var pickedImageData:Data!
    var loadNewImage:UIImage!
    
    // wait dlg for image upload request
    var mwait:Wait!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.profileImage.layer.cornerRadius = self.profileImage.frame.width / 2
        self.profileImage.layer.borderWidth = 0
        self.profileImage.layer.masksToBounds = true
        
        self.addImageButton.layer.cornerRadius = self.addImageButton.frame.width / 2
        self.addImageButton.layer.borderWidth = 0
        self.addImageButton.layer.masksToBounds = true

        // phone number
        phoneLabel.text! = Common.Shared.myProfileData.mPhoneNumber

        // birthday
        birthdayLabel.text! = Common.Shared.myProfileData.mBirthday
        
        showDatePicker()
        
        // image
        self.profileImage.kf.indicatorType = .activity
        self.profileImage.kf.setImage(
            with: URL(string: Common.SERVER_URL + Common.Shared.myProfileData.mPhoto_url ),
            placeholder: nil)
        self.loadNewImage = nil
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func goBack(_ sender: Any) {
        // goto the preview screen
        self.dismiss(animated: true, completion: nil)
    }

    func imgPicker( _ source : UIImagePickerControllerSourceType) {
        let picker = UIImagePickerController()
        picker.sourceType = source
        picker.delegate = self
        picker.allowsEditing = true
        self.present(picker, animated: true)
    }
    
    @IBAction func addImage(_ sender: Any) {
        let alert = UIAlertController(title: nil,
            message: NSLocalizedString("Image of profile", comment: ""),
            preferredStyle: .actionSheet)

        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            alert.addAction(UIAlertAction(
                title: NSLocalizedString("From Gallery", comment: ""),
                style: .default) { (_) in
                self.imgPicker(.photoLibrary)
            })
        }
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            alert.addAction(UIAlertAction(
            title: NSLocalizedString("From Camera", comment: ""),
            style: .default) { (_) in
                self.imgPicker(.camera)
            })
        }
        
        alert.addAction(UIAlertAction(
            title: NSLocalizedString("Remove image", comment: ""),
            style: .default) { (_) in
            if Common.Shared.myProfileData.mPhoto_url != "" {
                self.removeImageFromServer()
            }
        })
       
        alert.addAction(UIAlertAction(
            title: NSLocalizedString("Cancel", comment: ""),
            style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
            // reSize image with 100 * 100
            var reSizeImage = UIImage()
            reSizeImage = self.resizeImage(image: pickedImage, targetSize: CGSize(width: 100.0, height: 100.0))
            // picked image data
            // PNG
            self.pickedImageData = UIImagePNGRepresentation(reSizeImage)!
            // JPEG
//            self.pickedImageData = UIImageJPEGRepresentation(reSizeImage, 0.5)!
            self.loadNewImage = UIImage(data: self.pickedImageData)
        }
        // new image upload
        uploadImage()
        // goto the preview screen
        picker.dismiss(animated: false)
    }
    
    func showDatePicker(){
        //Formate Date
        let birthdayTxt =  birthdayLabel.text
        if birthdayTxt != "" {
            let birthdayStr = birthdayTxt!.split(separator: "/")
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/yyyy"
            let someDateTime = formatter.date(from: birthdayStr[0] + "/"
                + birthdayStr[1] + "/" + birthdayStr[2])
            datePicker.setDate(someDateTime!, animated: true)
        }
        datePicker.datePickerMode = .date
        
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(
            title: NSLocalizedString("Done", comment: ""),
            style: .plain, target: self, action: #selector(donedatePicker))
        doneButton.tintColor = UIColor.gray
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        toolbar.setItems([spaceButton, doneButton], animated: false)
        txtDatePicker.tintColor = UIColor.clear
        txtDatePicker.inputAccessoryView = toolbar
        txtDatePicker.inputView = datePicker
    }
    
    @objc func donedatePicker(){
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        
        loadNewBirthday = formatter.string(from: datePicker.date)
        // birthday modify?
        if loadNewBirthday != birthdayLabel.text {
            uploadBirthday()
        }
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
    
    // Upload the image
    func uploadImage() {
        let url = URL(string: Common.SERVER_URL + "users.php?options=upload_profile_image")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        let strData = self.pickedImageData.base64EncodedString()
        // body
        var postString = "user_id=" + Common.Shared.myProfileData.mUserID + "&base64=" + strData
        postString = postString.stringUrlEncoding()!
        request.httpBody = postString.data(using: .utf8)
        // ready the wait
        mwait = Wait(mParentView:self.view,
                     msg: NSLocalizedString("Updating profile image…", comment: ""),
                     bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                     fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
        mwait.startWait()
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 1
                if data != nil {
                    do {
                        // signin fail
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    check = 0
                                    print("success")
                                    let photoUrl = json["photo_url"] as? String
                                    print(photoUrl!)
                                    // get the image file name
                                    Common.Shared.myProfileData.mPhoto_url = photoUrl!
                                    self.profileImage.image = self.loadNewImage
                                    // write the profile
                                    Common.Shared.saveMyProfileDataFile(viewController:self, tableviewController:nil)
                                } else {  // fail?
                                    print("failure")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                // Stop the wait
                self.mwait.stopWait()
                if check != 0 {
                    if check == 1 {
                        Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                            message: NSLocalizedString("Failed.", comment: ""))
                    } else {
                        Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                            message: NSLocalizedString("Server is busy now.", comment: ""))
                    }
                }
            }
        }
        task.resume()
    }
    
    // Upload the birthday
    func uploadBirthday() {
        let url = URL(string: Common.SERVER_URL + "users.php?options=edit_birthday")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // body
        let postString = "user_id=" + Common.Shared.myProfileData.mUserID + "&birthday=" + loadNewBirthday
        request.httpBody = postString.data(using: .utf8)
        // ready the wait
        mwait = Wait(mParentView:self.view,
                     msg: NSLocalizedString("Updating birthday…", comment: ""),
                     bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                     fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
        mwait.startWait()
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 1
                if data != nil {
                    do {
                        // signin fail
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    check = 0
                                    print("success")
                                    // modify birthday
                                    self.birthdayLabel.text = self.loadNewBirthday
                                    Common.Shared.myProfileData.mBirthday = self.loadNewBirthday
                                    // write the profile
                                    Common.Shared.saveMyProfileDataFile(viewController:self, tableviewController:nil)
                                    
                                } else {  // fail?
                                    print("failure")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                // Stop the wait
                self.mwait.stopWait()
                if check == 1 {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Failed.", comment: ""))
                } else if check >= 2  {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Server is busy now.", comment: ""))
                }
            }
        }
        task.resume()
    }
    
    // remove the image
    func removeImageFromServer() {
        let url = URL(string: Common.SERVER_URL + "users.php?options=remove_profile_image")
        var request = URLRequest(url:url!)
        // header
        request.httpMethod = "POST"
        // body
        let postString = "user_id=" + Common.Shared.myProfileData.mUserID + "&photo_url=" + Common.Shared.myProfileData.mPhoto_url
        request.httpBody = postString.data(using: .utf8)
        // ready the wait
        mwait = Wait(mParentView:self.view,
                     msg: NSLocalizedString("Remove image", comment: ""),
                     bgColor:UIColor( red:255/255.0, green:255/255.0, blue:255/255.0, alpha:0.8),
                     fgColor:UIColor( red:7/255.0, green:92/255.0, blue:85/255.0, alpha:0.9))
        mwait.startWait()
        // send request
        let task = URLSession.shared.dataTask(with: request) {
            (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async() {
                var check = 1
                if data != nil {
                    do {
                        // signin fail
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any]
                        {
                            print(json)
                            if let result = json["result"] as? String {
                                // success?
                                if result == "success" {
                                    check = 0
                                    print("success")
                                    // modify image
                                    self.profileImage.image = UIImage(named: "add_profile")
                                    Common.Shared.myProfileData.mPhoto_url = ""
                                    // write the profile
                                    Common.Shared.saveMyProfileDataFile(viewController:self, tableviewController:nil)
                                    
                                } else {  // fail?
                                    print("failure")
                                }
                            }
                        }
                    } catch {
                        print("server error")
                        check = 2
                    }
                } else {
                    print("network error")
                    check = 3
                }
                // Stop the wait
                self.mwait.stopWait()
                if check == 1 {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Failed.", comment: ""))
                } else if check >= 2  {
                    Common.Shared.alertMessage(viewController:self, tableviewController:nil,
                        message: NSLocalizedString("Server is busy now.", comment: ""))
                }
            }
        }
        task.resume()
    }
    
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
}
